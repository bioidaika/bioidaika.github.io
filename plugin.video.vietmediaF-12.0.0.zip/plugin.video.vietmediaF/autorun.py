# -*- coding: utf-8 -*-
import json
import xbmc
import xbmcaddon


def _has_addon(addon_id):
    return bool(xbmc.getCondVisibility(f"System.HasAddon({addon_id})"))


def _sync_burst_apikey():
    try:
        vmf = xbmcaddon.Addon("plugin.video.vietmediaF")
        vmf_key = (vmf.getSetting("api_key") or "").strip()
        if not _has_addon("script.elementum.burst"):
            return
        burst = xbmcaddon.Addon("script.elementum.burst")
        burst_key = (burst.getSetting("vietmediaf_passkey") or "").strip()
        if vmf_key and vmf_key != burst_key:
            burst.setSetting("vietmediaf_passkey", vmf_key)
            burst.setSetting("use_vietmediaf", "true")
        elif burst_key and not vmf_key:
            vmf.setSetting("api_key", burst_key)
    except Exception as e:
        xbmc.log(f"[VietMediaF] API key sync skipped: {e}", xbmc.LOGDEBUG)


def main():
    _sync_burst_apikey()
    try:
        addon = xbmcaddon.Addon("plugin.video.vietmediaF")
        if addon.getSetting("chayvmf") == "true":
            xbmc.executebuiltin("RunAddon(plugin.video.vietmediaF)")
    except Exception:
        pass


if __name__ == "__main__":
    main()
