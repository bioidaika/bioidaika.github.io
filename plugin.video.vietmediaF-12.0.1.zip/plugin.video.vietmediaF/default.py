# -*- coding: utf-8 -*-
import json
import os
import re
import sys
import urllib.parse
import xml.etree.ElementTree as ET
import zipfile
from collections import OrderedDict

import requests
import xbmc
import xbmcaddon
import xbmcgui
import xbmcplugin
import xbmcvfs

ADDON_ID = "plugin.video.vietmediaF"
ADDON = xbmcaddon.Addon(ADDON_ID)
ADDON_NAME = ADDON.getAddonInfo("name")
ADDON_PATH = ADDON.getAddonInfo("path")
ADDON_ICON = os.path.join(ADDON_PATH, "icon.png")
ADDON_FANART = os.path.join(ADDON_PATH, "fanart.png")

HANDLE = int(sys.argv[1]) if len(sys.argv) > 1 and sys.argv[1].isdigit() else -1
BASE_URL = sys.argv[0] if len(sys.argv) > 0 else f"plugin://{ADDON_ID}/"

HTTP_TIMEOUT = 20
SESSION = requests.Session()
SESSION.headers.update({
    "User-Agent": "VietMediaF-Kodi/12.0 (+https://tracker.vietmediaf.store)",
    "Accept": "application/json",
})


def translate_path(path):
    if hasattr(xbmcvfs, "translatePath"):
        return xbmcvfs.translatePath(path)
    return xbmc.translatePath(path)


def log(msg, level=xbmc.LOGINFO):
    xbmc.log(f"[VietMediaF] {msg}", level)


def notify(title, message, icon=None, duration=4000):
    xbmcgui.Dialog().notification(title, message, icon or ADDON_ICON, duration)


def build_url(**kwargs):
    clean = {k: str(v) for k, v in kwargs.items() if v is not None and v != ""}
    return f"{BASE_URL}?{urllib.parse.urlencode(clean)}"


def get_tracker_url():
    url = (ADDON.getSetting("tracker_url") or "https://tracker.vietmediaf.store").strip().rstrip("/")
    return url or "https://tracker.vietmediaf.store"


def get_repo_url():
    url = (ADDON.getSetting("repo_url") or "https://kodi.vietmediaf.store").strip().rstrip("/")
    return url or "https://kodi.vietmediaf.store"


def get_per_page():
    idx = ADDON.getSetting("per_page") or "1"
    mapping = {"0": 25, "1": 50, "2": 100}
    return mapping.get(str(idx), 50)


def has_addon(addon_id):
    if xbmc.getCondVisibility(f"System.HasAddon({addon_id})"):
        return True
    addons_dir = translate_path("special://home/addons/")
    return os.path.isdir(os.path.join(addons_dir, addon_id))


def enable_addon(addon_id):
    try:
        payload = {
            "jsonrpc": "2.0",
            "id": 1,
            "method": "Addons.SetAddonEnabled",
            "params": {"addonid": addon_id, "enabled": True},
        }
        xbmc.executeJSONRPC(json.dumps(payload))
    except Exception as e:
        log(f"Failed to enable addon {addon_id}: {e}", xbmc.LOGWARNING)


def sync_api_key_with_burst(explicit_key=None):
    """Synchronize VietMediaF API key between plugin.video.vietmediaF and script.elementum.burst."""
    vmf_key = (explicit_key if explicit_key is not None else ADDON.getSetting("api_key") or "").strip()
    if explicit_key is not None:
        ADDON.setSetting("api_key", vmf_key)

    try:
        if has_addon("script.elementum.burst"):
            enable_addon("script.elementum.burst")
            burst = xbmcaddon.Addon("script.elementum.burst")
            burst_key = (burst.getSetting("vietmediaf_passkey") or "").strip()
            if vmf_key and vmf_key != burst_key:
                burst.setSetting("vietmediaf_passkey", vmf_key)
                burst.setSetting("use_vietmediaf", "true")
            elif burst_key and not vmf_key:
                ADDON.setSetting("api_key", burst_key)
                vmf_key = burst_key
    except Exception as e:
        log(f"Burst API key sync fallback: {e}", xbmc.LOGDEBUG)
        try:
            burst_data_dir = translate_path("special://profile/addon_data/script.elementum.burst")
            os.makedirs(burst_data_dir, exist_ok=True)
            settings_path = os.path.join(burst_data_dir, "settings.xml")
            if os.path.isfile(settings_path):
                tree = ET.parse(settings_path)
                root = tree.getroot()
            else:
                root = ET.Element("settings", version="2")
                tree = ET.ElementTree(root)

            if vmf_key:
                _set_xml_setting(root, "vietmediaf_passkey", vmf_key)
                _set_xml_setting(root, "use_vietmediaf", "true")
                tree.write(settings_path, encoding="utf-8", xml_declaration=True)
        except Exception as inner_e:
            log(f"Burst XML settings sync error: {inner_e}", xbmc.LOGWARNING)

    return vmf_key


def _set_xml_setting(root, setting_id, value):
    for elem in root.findall("setting"):
        if elem.attrib.get("id") == setting_id:
            elem.text = str(value)
            if "default" in elem.attrib:
                del elem.attrib["default"]
            return
    new_elem = ET.SubElement(root, "setting", id=setting_id)
    new_elem.text = str(value)


def format_size(num_bytes):
    try:
        size = float(num_bytes or 0)
    except (ValueError, TypeError):
        return "0 B"
    for unit in ["B", "KB", "MB", "GB", "TB"]:
        if size < 1024.0 or unit == "TB":
            return f"{size:.2f} {unit}" if unit in ("GB", "TB") else f"{size:.0f} {unit}"
        size /= 1024.0
    return f"{size:.2f} TB"


def detect_audio_badges(name):
    upper = (name or "").upper()
    badges = []
    if "VIE DUB" in upper or "VIEDUB" in upper or "THUYẾT MINH" in upper or "LỒNG TIẾNG" in upper:
        badges.append("[COLOR lime]ViE DUB[/COLOR]")
    elif re.search(r"\bVIE\b", upper) or "VIETSUB" in upper or "SUB VIET" in upper:
        badges.append("[COLOR lime]ViE[/COLOR]")
    if "ATMOS" in upper:
        badges.append("[COLOR deepskyblue]Atmos[/COLOR]")
    if "DV" in upper or "DOLBY VISION" in upper or "DOVI" in upper:
        badges.append("[COLOR magenta]DV[/COLOR]")
    elif "HDR10+" in upper:
        badges.append("[COLOR violet]HDR10+[/COLOR]")
    elif "HDR" in upper:
        badges.append("[COLOR violet]HDR[/COLOR]")
    return " ".join(badges)


def clean_release_title(name):
    if not name:
        return "Unknown"
    cleaned = re.sub(r"^\[[^\]]+\]\s*", "", name)
    match = re.match(r"^(.+?)\s+((?:19|20)\d{2})\b", cleaned)
    if match:
        return match.group(1).replace(".", " ").strip()
    match_se = re.match(r"^(.+?)\s+S\d{1,2}(?:E\d{1,3})?\b", cleaned, re.IGNORECASE)
    if match_se:
        return match_se.group(1).replace(".", " ").strip()
    return cleaned


def apply_video_info(list_item, info):
    """Apply video metadata using InfoTagVideo on Kodi 20+ with fallback to setInfo."""
    title = info.get("title") or ""
    original_title = info.get("originaltitle") or title
    plot = info.get("plot") or ""
    year = int(info.get("year") or 0)
    rating = float(info.get("rating") or 0.0)
    duration = int(info.get("duration") or 0)
    mediatype = info.get("mediatype") or "movie"
    genres = info.get("genres") or []
    if isinstance(genres, str):
        genres = [g.strip() for g in genres.split(",") if g.strip()]

    try:
        tag = list_item.getVideoInfoTag()
        tag.setTitle(title)
        if original_title:
            tag.setOriginalTitle(original_title)
        if plot:
            tag.setPlot(plot)
        if year > 0:
            tag.setYear(year)
        if rating > 0:
            tag.setRating(rating)
        if duration > 0:
            tag.setDuration(duration)
        if genres:
            tag.setGenres(genres)
        tag.setMediaType(mediatype)
        if info.get("season"):
            tag.setSeason(int(info["season"]))
        if info.get("episode"):
            tag.setEpisode(int(info["episode"]))
    except Exception:
        legacy = {
            "title": title,
            "originaltitle": original_title,
            "plot": plot,
            "mediatype": mediatype,
        }
        if year > 0:
            legacy["year"] = year
        if rating > 0:
            legacy["rating"] = rating
        if duration > 0:
            legacy["duration"] = duration
        if genres:
            legacy["genre"] = ", ".join(genres)
        list_item.setInfo("video", legacy)


def api_get(endpoint, params=None, api_key=None):
    key = sync_api_key_with_burst(api_key)
    if not key:
        return None, "Chưa cấu hình API Key"

    url = f"{get_tracker_url()}{endpoint}"
    headers = {"Authorization": f"Bearer {key}"}
    try:
        resp = SESSION.get(url, params=params, headers=headers, timeout=HTTP_TIMEOUT)
        if resp.status_code in (401, 403):
            return None, "API Key không hợp lệ hoặc đã hết hạn (HTTP 401/403)."
        if resp.status_code != 200:
            return None, f"Lỗi máy chủ Tracker (HTTP {resp.status_code})."
        return resp.json(), None
    except requests.RequestException as e:
        log(f"API request failed ({url}): {e}", xbmc.LOGERROR)
        return None, f"Không thể kết nối tới {get_tracker_url()}: {e}"


def fetch_user_profile(api_key=None):
    data, err = api_get("/api/user", api_key=api_key)
    if err or not isinstance(data, dict):
        return None, err
    for byte_field in ("uploaded", "downloaded", "buffer"):
        val = data.get(byte_field)
        if val is None and byte_field == "buffer":
            data[byte_field] = "Inf"
        elif isinstance(val, (int, float)):
            data[byte_field] = format_size(val)
    if data.get("ratio") is None:
        data["ratio"] = "Inf"
    return data, None


def check_and_install_elementum(force_interactive=False):
    """Check if Elementum and Elementum Burst (v0.0.103+) are installed; offer 1-click installation."""
    has_el = has_addon("plugin.video.elementum")
    has_burst = has_addon("script.elementum.burst")
    burst_ver_ok = False
    if has_burst:
        try:
            ver = xbmcaddon.Addon("script.elementum.burst").getAddonInfo("version")
            parts = [int(x) for x in re.findall(r"\d+", ver)]
            burst_ver_ok = parts >= [0, 0, 103]
        except Exception:
            burst_ver_ok = True

    if has_el and has_burst and burst_ver_ok and not force_interactive:
        return True

    if not force_interactive and ADDON.getSetting("elementum_prompted") == "true" and has_el:
        return True

    ADDON.setSetting("elementum_prompted", "true")
    missing_desc = []
    if not has_el:
        missing_desc.append("• [B]Elementum[/B] (Trình phát P2P BitTorrent tốc độ cao)")
    if not has_burst or not burst_ver_ok:
        missing_desc.append("• [B]Elementum Burst v0.0.103[/B] (Tích hợp 45 Tracker UNIT3D + VietMediaF)")

    if not missing_desc and force_interactive:
        missing_desc.append("• [B]Cài đặt lại / Cập nhật bộ Elementum + Elementum Burst (45 Tracker UNIT3D)[/B]")

    msg = (
        "[COLOR gold][B]VietMediaF v12.0[/B][/COLOR] sử dụng engine [B]Elementum[/B] để phát trực tiếp "
        "phim 4K UHD / BluRay Remux từ [B]tracker.vietmediaf.store[/B] và 45 Tracker UNIT3D.\n\n"
        + "\n".join(missing_desc)
        + "\n\nBạn có muốn tự động tải về và kích hoạt ngay bây giờ không?"
    )
    if not xbmcgui.Dialog().yesno("Cài đặt Elementum & Burst", msg, nolabel="Để sau", yeslabel="Cài đặt ngay"):
        return False

    repo = get_repo_url()
    packages = [
        (
            "plugin.video.elementum",
            "Elementum P2P Engine (v0.1.119 - All Platforms)",
            [
                f"{repo}/plugin.video.elementum/plugin.video.elementum-0.1.119.zip",
                "https://github.com/elgatito/plugin.video.elementum/releases/download/v0.1.119/plugin.video.elementum-0.1.119.zip",
            ],
        ),
        (
            "script.elementum.burst",
            "Elementum Burst (v0.0.103 - 45 UNIT3D Trackers)",
            [
                f"{repo}/script.elementum.burst/script.elementum.burst-0.0.103.zip",
                f"{repo}/script.elementum.burst-0.0.103.zip",
                "https://github.com/bioidaika/script.elementum.burst/archive/refs/heads/master.zip",
            ],
        ),
        (
            "context.elementum",
            "Elementum Context Menu (v0.0.17)",
            [
                f"{repo}/context.elementum/context.elementum-0.0.17.zip",
                f"{repo}/context.elementum-0.0.17.zip",
                "https://github.com/elgatito/context.elementum/releases/download/v0.0.17/context.elementum-0.0.17.zip",
            ],
        ),
    ]

    addons_dir = translate_path("special://home/addons/")
    packages_dir = translate_path("special://home/addons/packages/")
    os.makedirs(packages_dir, exist_ok=True)

    progress = xbmcgui.DialogProgress()
    progress.create("VietMediaF — Cài đặt Elementum", "Đang chuẩn bị tải gói cài đặt...")

    installed_any = False
    for idx, (pkg_id, label, urls) in enumerate(packages):
        if progress.iscanceled():
            break
        pct = int((idx / len(packages)) * 100)
        progress.update(pct, f"Đang tải {label}...")

        zip_path = os.path.join(packages_dir, f"{pkg_id}.zip")
        downloaded = False
        for url in urls:
            try:
                with SESSION.get(url, stream=True, timeout=60) as r:
                    if r.status_code == 200:
                        with open(zip_path, "wb") as f:
                            for chunk in r.iter_content(chunk_size=65536):
                                if chunk:
                                    f.write(chunk)
                        downloaded = True
                        break
            except Exception as e:
                log(f"Download failed from {url}: {e}", xbmc.LOGWARNING)

        if not downloaded:
            log(f"Could not download package {pkg_id}", xbmc.LOGERROR)
            continue

        progress.update(pct + 15, f"Đang giải nén {label}...")
        try:
            with zipfile.ZipFile(zip_path, "r") as zf:
                names = zf.namelist()
                top_Read = names[0].split("/")[0] if names else ""
                zf.extractall(addons_dir)
                # Handle GitHub archive zip (e.g. script.elementum.burst-master -> script.elementum.burst)
                if top_Read and top_Read != pkg_id and top_Read.startswith(pkg_id):
                    extracted_dir = os.path.join(addons_dir, top_Read)
                    target_dir = os.path.join(addons_dir, pkg_id)
                    if os.path.isdir(extracted_dir):
                        import shutil
                        if os.path.isdir(target_dir):
                            shutil.rmtree(target_dir, ignore_errors=True)
                        shutil.move(extracted_dir, target_dir)
            enable_addon(pkg_id)
            installed_any = True
        except Exception as e:
            log(f"Failed to extract {pkg_id}: {e}", xbmc.LOGERROR)

    progress.update(100, "Đang cập nhật hệ thống Addon của Kodi...")
    xbmc.executebuiltin("UpdateLocalAddons")
    xbmc.sleep(1500)
    for pkg_id, _, _ in packages:
        enable_addon(pkg_id)
    sync_api_key_with_burst()
    progress.close()

    if installed_any:
        xbmcgui.Dialog().ok(
            "VietMediaF — Hoàn tất cài đặt",
            "Đã cài đặt và kích hoạt thành công [B]Elementum[/B] + [B]Elementum Burst (45 Tracker UNIT3D)[/B]!\n"
            "API Key VietMediaF của bạn cũng đã được đồng bộ tự động.",
        )
    return installed_any


def action_set_api_key():
    current_key = sync_api_key_with_burst()
    kb = xbmc.Keyboard(current_key, "Nhập API Key của bạn trên tracker.vietmediaf.store")
    kb.doModal()
    if not kb.isConfirmed():
        return
    new_key = (kb.getText() or "").strip()
    if not new_key:
        notify("VietMediaF", "API Key không được để trống.", xbmcgui.NOTIFICATION_WARNING)
        return

    sync_api_key_with_burst(new_key)
    profile, err = fetch_user_profile(new_key)
    if profile and profile.get("username"):
        xbmcgui.Dialog().ok(
            "Kết nối VietMediaF Tracker thành công!",
            f"Xin chào [COLOR lime][B]{profile.get('username')}[/B][/COLOR] ({profile.get('group', 'Member')})!\n"
            f"Upload: [B]{profile.get('uploaded', '0 B')}[/B]   |   Download: [B]{profile.get('downloaded', '0 B')}[/B]\n"
            f"Ratio: [B]{profile.get('ratio', '0')}[/B]   |   Điểm thưởng: [B]{profile.get('seedbonus', 0)} BON[/B]\n"
            "API Key đã được đồng bộ tự động sang Elementum Burst.",
        )
    else:
        xbmcgui.Dialog().ok(
            "Đã lưu API Key",
            f"Đã lưu API Key và đồng bộ sang Elementum Burst.\nLưu ý khi kiểm tra hồ sơ: {err or 'Không rõ'}",
        )
    xbmc.executebuiltin("Container.Refresh")


def action_account_info():
    key = sync_api_key_with_burst()
    if not key:
        action_set_api_key()
        return
    profile, err = fetch_user_profile(key)
    if not profile:
        if xbmcgui.Dialog().yesno(
            "Lỗi xác thực API Key",
            f"Không thể lấy thông tin tài khoản:\n{err}\n\nBạn có muốn nhập lại API Key không?",
        ):
            action_set_api_key()
        return

    lines = [
        f"• Tài khoản: [COLOR lime][B]{profile.get('username')}[/B][/COLOR]  —  Nhóm: [COLOR gold][B]{profile.get('group')}[/B][/COLOR]",
        f"• Đã tải lên (Upload): [COLOR green][B]{profile.get('uploaded')}[/B][/COLOR]  |  Đã tải xuống (Download): [COLOR orange][B]{profile.get('downloaded')}[/B][/COLOR]",
        f"• Tỉ lệ (Ratio): [COLOR cyan][B]{profile.get('ratio')}[/B][/COLOR]  |  Buffer: [B]{profile.get('buffer')}[/B]",
        f"• Điểm thưởng (Seedbonus): [COLOR yellow][B]{profile.get('seedbonus')} BON[/B][/COLOR]",
        f"• Đang Seeding: [COLOR lime][B]{profile.get('seeding')}[/B][/COLOR]  |  Đang Leeching: [B]{profile.get('leeching')}[/B]  |  Hit & Runs: [B]{profile.get('hit_and_runs')}[/B]",
    ]
    if xbmcgui.Dialog().yesno(
        "Thông tin tài khoản VietMediaF Tracker",
        "\n".join(lines),
        nolabel="Đóng",
        yeslabel="Đổi API Key",
    ):
        action_set_api_key()


def add_menu_item(label, url, is_folder=True, icon=None, fanart=None, plot="", info=None, context_items=None, is_playable=False):
    li = xbmcgui.ListItem(label=label)
    poster = icon or ADDON_ICON
    backdrop = fanart or ADDON_FANART
    li.setArt({
        "icon": poster,
        "thumb": poster,
        "poster": poster,
        "fanart": backdrop,
        "landscape": backdrop,
    })
    meta = info or {"title": label, "plot": plot or label, "mediatype": "video"}
    if plot and not meta.get("plot"):
        meta["plot"] = plot
    apply_video_info(li, meta)
    if is_playable:
        li.setProperty("IsPlayable", "true")
    if context_items:
        li.addContextMenuItems(context_items)
    xbmcplugin.addDirectoryItem(handle=HANDLE, url=url, listitem=li, isFolder=is_folder)


def action_main_menu():
    check_and_install_elementum(force_interactive=False)
    key = sync_api_key_with_burst()

    if key:
        profile, _ = fetch_user_profile(key)
        if profile and profile.get("username"):
            acct_label = (
                f"[COLOR lime][B][{profile.get('username')}][/B][/COLOR] ([COLOR gold]{profile.get('group')}[/COLOR]) "
                f"| Up: {profile.get('uploaded')} / Down: {profile.get('downloaded')} "
                f"| Ratio: [COLOR cyan]{profile.get('ratio')}[/COLOR] "
                f"| [COLOR yellow]{profile.get('seedbonus')} BON[/COLOR] "
                f"| Seed: [COLOR lime]{profile.get('seeding')}[/COLOR]"
            )
            add_menu_item(
                acct_label,
                build_url(action="account_info"),
                is_folder=False,
                plot="Xem chi tiết thống kê tài khoản VietMediaF Tracker hoặc đổi API Key.",
            )
        else:
            add_menu_item(
                "[COLOR orange][B][!] API Key không hợp lệ hoặc mất kết nối — Nhấn để kiểm tra / nhập lại[/B][/COLOR]",
                build_url(action="set_api_key"),
                is_folder=False,
                plot="Kiểm tra hoặc nhập lại API Key từ https://tracker.vietmediaf.store",
            )
    else:
        add_menu_item(
            "[COLOR yellow][B][API KEY] Nhập API Key VietMediaF Tracker (Bắt buộc để duyệt & tải phim)[/B][/COLOR]",
            build_url(action="set_api_key"),
            is_folder=False,
            plot="Lấy API Key trong mục Thiết lập -> API Key trên https://tracker.vietmediaf.store. Tự động đồng bộ với Elementum Burst.",
        )

    menu_entries = [
        ("[COLOR gold][HOT][/COLOR] [B]Phim Đề Cử (Featured Torrents)[/B]", "featured", "Danh sách phim đặc sắc được Ban Quản Trị VietMediaF đề cử (thường kèm Freeleech 100%)."),
        ("[COLOR cyan][MỚI][/COLOR] [B]Mới Cập Nhật (Tất Cả Phim)[/B]", "latest_all", "Toàn bộ Torrent mới nhất vừa được upload lên VietMediaF Tracker."),
        ("[COLOR deepskyblue][PHIM LẺ][/COLOR] [B]Phim Lẻ Mới Nhất (Movies)[/B]", "movies_new", "Danh sách Phim Điện Ảnh (Movies) mới nhất, gom nhóm thông minh theo TMDB."),
        ("[COLOR violet][PHIM BỘ][/COLOR] [B]Phim Bộ / Series Mới Nhất (TV Shows)[/B]", "tv_new", "Danh sách Phim Bộ / Series truyền hình mới nhất trên VietMediaF."),
        ("[COLOR lime][ViE DUB][/COLOR] [B]Phim Thuyết Minh / Lồng Tiếng[/B]", "vie_dub", "Tuyển tập phim có âm thanh Thuyết Minh hoặc Lồng Tiếng Việt chất lượng cao."),
        ("[COLOR lime][ViE SUB][/COLOR] [B]Phim Phụ Đề Tiếng Việt[/B]", "vie_sub", "Tuyển tập phim có Phụ Đề Tiếng Việt chuẩn trên VietMediaF Tracker."),
        ("[COLOR orange][FREELEECH][/COLOR] [B]Phim Miễn Phí 100% Dung Lượng Tải[/B]", "freeleech", "Tải và xem thoải mái không tính dung lượng Download, chỉ cộng Upload & Điểm thưởng BON!"),
        ("[COLOR magenta][4K UHD][/COLOR] [B]Phim 4K UHD / BluRay Remux / Dolby Vision[/B]", "uhd_4k", "Phim chất lượng siêu nét 2160p 4K UHD, Remux, Dolby Vision & HDR10+."),
        ("[COLOR green][TOP SEED][/COLOR] [B]Xem Mượt Nhất — Nhiều Người Giữ Seed[/B]", "top_seeds", "Danh sách phim có nhiều người đang giữ seed nhất, bấm phát chạy ngay lập tức."),
    ]
    for label, preset, desc in menu_entries:
        add_menu_item(label, build_url(action="browse", preset=preset, page=1), is_folder=True, plot=desc)

    add_menu_item(
        "[COLOR cyan][B][TÌM KIẾM] Tìm Phim Trên VietMediaF Tracker[/B][/COLOR]",
        build_url(action="search"),
        is_folder=True,
        plot="Tìm kiếm theo tên phim (Tiếng Việt / Tiếng Anh) hoặc mã TMDB ID trực tiếp trên VietMediaF.",
    )
    add_menu_item(
        "[COLOR deepskyblue][B][ĐA TRACKER] Tìm Kiếm Trên 45 Tracker UNIT3D (Elementum Burst)[/B][/COLOR]",
        "plugin://plugin.video.elementum/search",
        is_folder=True,
        plot="Mở công cụ tìm kiếm của Elementum và quét đồng thời 45 Private Tracker UNIT3D qua Elementum Burst.",
    )
    add_menu_item(
        "[COLOR lime][B][ELEMENTUM] Mở Giao Diện Elementum (Torrents Đang Tải / Thư Viện)[/B][/COLOR]",
        "plugin://plugin.video.elementum/",
        is_folder=True,
        plot="Mở trực tiếp giao diện quản lý tiến trình tải, bộ nhớ đệm và thư viện của Elementum.",
    )
    add_menu_item(
        "[B][API KEY] Nhập / Đổi API Key VietMediaF Tracker[/B]",
        build_url(action="set_api_key"),
        is_folder=False,
        plot="Cập nhật API Key và tự động đồng bộ sang Elementum Burst.",
    )
    add_menu_item(
        "[B][CÀI ĐẶT] Cài Đặt / Cập Nhật Trình Phát Elementum & Burst (45 UNIT3D)[/B]",
        build_url(action="install_elementum"),
        is_folder=False,
        plot="Tự động tải về, cài đặt và kích hoạt Elementum + Elementum Burst v0.0.103 + Context Menu.",
    )
    add_menu_item(
        "[B][CẤU HÌNH] Thiết Lập VietMediaF Addon[/B]",
        build_url(action="open_settings"),
        is_folder=False,
        plot="Mở bảng cài đặt VietMediaF Addon.",
    )

    xbmcplugin.setContent(HANDLE, "videos")
    xbmcplugin.endOfDirectory(HANDLE, cacheToDisc=False)


def build_filter_params(preset, page=1, query="", tmdb_id="", category_id=""):
    params = {
        "perPage": get_per_page(),
        "page": int(page or 1),
    }
    if tmdb_id:
        params["tmdbId"] = tmdb_id
        params["perPage"] = 100
    if category_id:
        params["categories[0]"] = category_id
    if query:
        if query.isdigit():
            params["tmdbId"] = query
        else:
            params["name"] = query

    if preset == "featured":
        params["featured"] = 1
    elif preset == "movies_new":
        params["categories[0]"] = 1
        params["sortField"] = "created_at"
        params["sortDirection"] = "desc"
    elif preset == "tv_new":
        params["categories[0]"] = 2
        params["sortField"] = "created_at"
        params["sortDirection"] = "desc"
    elif preset == "vie_dub":
        params["name"] = "ViE DUB"
        params["sortField"] = "created_at"
        params["sortDirection"] = "desc"
    elif preset == "vie_sub":
        params["name"] = "ViE"
        params["sortField"] = "created_at"
        params["sortDirection"] = "desc"
    elif preset == "freeleech":
        params["freeleech"] = 1
        params["sortField"] = "created_at"
        params["sortDirection"] = "desc"
    elif preset == "uhd_4k":
        params["resolutions[0]"] = 1
        params["resolutions[1]"] = 2
        params["sortField"] = "created_at"
        params["sortDirection"] = "desc"
    elif preset == "top_seeds":
        params["alive"] = 1
        params["sortField"] = "seeders"
        params["sortDirection"] = "desc"
    else:
        params.setdefault("sortField", "created_at")
        params.setdefault("sortDirection", "desc")

    return params


def extract_torrent_item(raw):
    attrs = raw.get("attributes") or {}
    meta = attrs.get("meta") or {}
    name = attrs.get("name") or "Unknown Release"
    tmdb_id = int(attrs.get("tmdb_id") or 0)
    category_id = int(attrs.get("category_id") or 1)
    seeders = int(attrs.get("seeders") or 0)
    leechers = int(attrs.get("leechers") or 0)
    size = int(attrs.get("size") or 0)
    freeleech = str(attrs.get("freeleech") or "0%")
    double_upload = bool(attrs.get("double_upload"))
    featured = bool(attrs.get("featured"))
    resolution = attrs.get("resolution") or ""
    release_type = attrs.get("type") or ""
    download_link = attrs.get("download_link") or ""
    details_link = attrs.get("details_link") or ""
    season_number = int(attrs.get("season_number") or 0)
    episode_number = int(attrs.get("episode_number") or 0)

    clean_title = meta.get("title") or clean_release_title(name)
    original_title = meta.get("original_title") or clean_title
    year = int(attrs.get("release_year") or 0)
    if not year:
        ym = re.search(r"\b((?:19|20)\d{2})\b", name)
        if ym:
            year = int(ym.group(1))

    poster = meta.get("poster") or ADDON_ICON
    backdrop = meta.get("backdrop") or ADDON_FANART
    overview = meta.get("overview") or ""
    rating = float(meta.get("rating") or 0.0)
    runtime = int(meta.get("runtime") or 0) * 60
    genres = meta.get("genres") or ""

    return {
        "id": raw.get("id"),
        "name": name,
        "title": clean_title,
        "original_title": original_title,
        "year": year,
        "tmdb_id": tmdb_id,
        "category_id": category_id,
        "seeders": seeders,
        "leechers": leechers,
        "size": size,
        "size_str": format_size(size),
        "freeleech": freeleech,
        "double_upload": double_upload,
        "featured": featured,
        "resolution": resolution,
        "type": release_type,
        "download_link": download_link,
        "details_link": details_link,
        "season_number": season_number,
        "episode_number": episode_number,
        "poster": poster,
        "backdrop": backdrop,
        "overview": overview,
        "rating": rating,
        "duration": runtime,
        "genres": genres,
    }


def render_single_torrent_item(item, show_clean_title=False):
    res_type = " ".join(x for x in [item["resolution"], item["type"]] if x).strip()
    audio_badges = detect_audio_badges(item["name"])
    fl_badge = ""
    if item["featured"]:
        fl_badge = "[COLOR gold][FEATURED][/COLOR] "
    elif item["freeleech"] and item["freeleech"] != "0%":
        fl_badge = f"[COLOR orange][FL {item['freeleech']}][/COLOR] "

    se_badge = ""
    if item["category_id"] == 2 and (item["season_number"] > 0 or item["episode_number"] > 0):
        if item["episode_number"] > 0:
            se_badge = f"[COLOR yellow]S{item['season_number']:02d}E{item['episode_number']:02d}[/COLOR] "
        else:
            se_badge = f"[COLOR yellow]Season {item['season_number']}[/COLOR] "

    seed_color = "lime" if item["seeders"] > 0 else "red"
    if show_clean_title:
        year_str = f" ({item['year']})" if item["year"] else ""
        label = (
            f"[B]{item['title']}{year_str}[/B] — {se_badge}"
            f"[COLOR cyan][{res_type}][/COLOR] [COLOR silver]{item['size_str']}[/COLOR] "
            f"{audio_badges} {fl_badge}[COLOR {seed_color}][Seed: {item['seeders']}][/COLOR]"
        )
    else:
        label = (
            f"[COLOR {seed_color}][Seed: {item['seeders']}][/COLOR] | "
            f"[COLOR silver][B]{item['size_str']}[/B][/COLOR] | "
            f"{se_badge}[COLOR cyan][{res_type}][/COLOR] "
            f"{audio_badges} {fl_badge}— {item['name']}"
        )

    plot_lines = [
        f"• Bản phát hành: [B]{item['name']}[/B]",
        f"• Dung lượng: [B]{item['size_str']}[/B]  |  Chất lượng: [B]{res_type}[/B]",
        f"• Seeders: [COLOR lime][B]{item['seeders']}[/B][/COLOR]  |  Leechers: [B]{item['leechers']}[/B]  |  Freeleech: [B]{item['freeleech']}[/B]",
    ]
    if item["overview"]:
        plot_lines.append("")
        plot_lines.append(item["overview"])

    play_url = build_url(
        action="play",
        download_link=item["download_link"],
        tmdb_id=item["tmdb_id"],
        category_id=item["category_id"],
        title=item["title"],
    )

    context_items = []
    if item["tmdb_id"] > 0:
        el_url = (
            f"plugin://plugin.video.elementum/movie/{item['tmdb_id']}/links"
            if item["category_id"] == 1
            else f"plugin://plugin.video.elementum/show/{item['tmdb_id']}/seasons"
        )
        context_items.append((
            "Quét 45 Tracker UNIT3D (Elementum Burst)",
            f"Container.Update({el_url})",
        ))
        context_items.append((
            "Xem tất cả bản Torrent của phim này trên VietMediaF",
            f"Container.Update({build_url(action='versions', tmdb_id=item['tmdb_id'], category_id=item['category_id'], title=item['title'])})",
        ))

    info = {
        "title": item["title"],
        "originaltitle": item["original_title"],
        "year": item["year"],
        "plot": "\n".join(plot_lines),
        "rating": item["rating"],
        "duration": item["duration"],
        "genres": item["genres"],
        "mediatype": "movie" if item["category_id"] == 1 else "tvshow",
        "season": item["season_number"],
        "episode": item["episode_number"],
    }
    add_menu_item(
        label=label,
        url=play_url,
        is_folder=False,
        icon=item["poster"],
        fanart=item["backdrop"],
        info=info,
        context_items=context_items,
        is_playable=True,
    )


def action_browse(params):
    preset = params.get("preset", "latest_all")
    page = int(params.get("page") or 1)
    query = params.get("query", "")

    api_params = build_filter_params(preset=preset, page=page, query=query)
    payload, err = api_get("/api/torrents/filter", params=api_params)
    if err:
        if "API Key" in err:
            if xbmcgui.Dialog().yesno("Cần cấu hình API Key", f"{err}\n\nBạn có muốn nhập API Key ngay bây giờ không?"):
                action_set_api_key()
        else:
            notify("VietMediaF", err, xbmcgui.NOTIFICATION_ERROR)
        xbmcplugin.endOfDirectory(HANDLE, succeeded=False)
        return

    raw_items = (payload or {}).get("data") or []
    items = [extract_torrent_item(x) for x in raw_items if isinstance(x, dict)]

    if not items:
        notify("VietMediaF", "Không tìm thấy kết quả phù hợp.", xbmcgui.NOTIFICATION_INFO)
        xbmcplugin.endOfDirectory(HANDLE, succeeded=True)
        return

    group_by_tmdb = ADDON.getSetting("group_by_tmdb") != "false"
    direct_play_single = ADDON.getSetting("direct_play_single") == "true"

    if not group_by_tmdb:
        for item in items:
            render_single_torrent_item(item, show_clean_title=True)
    else:
        groups = OrderedDict()
        for item in items:
            if item["tmdb_id"] > 0:
                gkey = (item["category_id"], item["tmdb_id"])
            else:
                gkey = ("raw", item["id"])
            groups.setdefault(gkey, []).append(item)

        for gkey, group_items in groups.items():
            primary = group_items[0]
            count = len(group_items)
            if count == 1 and direct_play_single:
                render_single_torrent_item(primary, show_clean_title=True)
                continue

            resolutions = []
            for gi in group_items:
                if gi["resolution"] and gi["resolution"] not in resolutions:
                    resolutions.append(gi["resolution"])
            res_summary = "/".join(resolutions[:3])

            all_names = " ".join(gi["name"] for gi in group_items)
            audio_summary = detect_audio_badges(all_names)
            has_fl = any(gi["freeleech"] != "0%" or gi["featured"] for gi in group_items)
            fl_str = "[COLOR orange][FL][/COLOR] " if has_fl else ""
            total_seeds = sum(gi["seeders"] for gi in group_items)
            seed_color = "lime" if total_seeds > 0 else "red"
            year_str = f" ({primary['year']})" if primary["year"] else ""
            cat_badge = "[COLOR deepskyblue][LẺ][/COLOR]" if primary["category_id"] == 1 else "[COLOR violet][BỘ][/COLOR]"

            label = (
                f"{cat_badge} [B]{primary['title']}{year_str}[/B]  "
                f"[COLOR gold][{count} bản][/COLOR] "
                f"[COLOR cyan][{res_summary}][/COLOR] "
                f"{audio_summary} {fl_str}"
                f"[COLOR {seed_color}][Seed: {total_seeds}][/COLOR]"
            )

            version_lines = [
                f"• {gi['resolution']} {gi['type']} ({gi['size_str']}) — Seed: {gi['seeders']} — {gi['name']}"
                for gi in group_items[:6]
            ]
            plot_text = (primary["overview"] + "\n\n" if primary["overview"] else "") + "Các bản hiện có:\n" + "\n".join(version_lines)

            if primary["tmdb_id"] > 0:
                target_url = build_url(
                    action="versions",
                    tmdb_id=primary["tmdb_id"],
                    category_id=primary["category_id"],
                    title=primary["title"],
                )
            else:
                target_url = build_url(
                    action="play",
                    download_link=primary["download_link"],
                    tmdb_id=0,
                    category_id=primary["category_id"],
                    title=primary["title"],
                )

            context_items = []
            if primary["tmdb_id"] > 0:
                el_url = (
                    f"plugin://plugin.video.elementum/movie/{primary['tmdb_id']}/links"
                    if primary["category_id"] == 1
                    else f"plugin://plugin.video.elementum/show/{primary['tmdb_id']}/seasons"
                )
                context_items.append((
                    "Quét 45 Tracker UNIT3D (Elementum Burst)",
                    f"Container.Update({el_url})",
                ))

            info = {
                "title": primary["title"],
                "originaltitle": primary["original_title"],
                "year": primary["year"],
                "plot": plot_text,
                "rating": primary["rating"],
                "duration": primary["duration"],
                "genres": primary["genres"],
                "mediatype": "movie" if primary["category_id"] == 1 else "tvshow",
            }
            add_menu_item(
                label=label,
                url=target_url,
                is_folder=(primary["tmdb_id"] > 0),
                icon=primary["poster"],
                fanart=primary["backdrop"],
                info=info,
                context_items=context_items,
                is_playable=(primary["tmdb_id"] == 0),
            )

    links = (payload or {}).get("links") or {}
    meta_page = (payload or {}).get("meta") or {}
    current_page = int(meta_page.get("current_page") or page)
    last_page = int(meta_page.get("last_page") or current_page)
    if links.get("next") or current_page < last_page:
        next_page = current_page + 1
        add_menu_item(
            f"[COLOR yellow][B]>> Trang tiếp theo (Trang {next_page})[/B][/COLOR]",
            build_url(action="browse", preset=preset, page=next_page, query=query),
            is_folder=True,
            plot=f"Chuyển sang trang {next_page}.",
        )

    xbmcplugin.setContent(HANDLE, "movies")
    xbmcplugin.endOfDirectory(HANDLE, cacheToDisc=True)


def action_versions(params):
    tmdb_id = int(params.get("tmdb_id") or 0)
    category_id = int(params.get("category_id") or 1)
    title = params.get("title") or "Danh sách bản phim"

    api_params = build_filter_params(
        preset="versions",
        page=1,
        tmdb_id=str(tmdb_id),
        category_id=str(category_id),
    )
    payload, err = api_get("/api/torrents/filter", params=api_params)
    if err:
        notify("VietMediaF", err, xbmcgui.NOTIFICATION_ERROR)
        xbmcplugin.endOfDirectory(HANDLE, succeeded=False)
        return

    raw_items = (payload or {}).get("data") or []
    items = [extract_torrent_item(x) for x in raw_items if isinstance(x, dict)]
    if category_id == 2:
        items.sort(key=lambda x: (x["season_number"], x["episode_number"], -x["seeders"], -x["size"]))
    else:
        items.sort(key=lambda x: (-x["seeders"], -x["size"]))

    for item in items:
        render_single_torrent_item(item, show_clean_title=False)

    if tmdb_id > 0:
        el_url = (
            f"plugin://plugin.video.elementum/movie/{tmdb_id}/links"
            if category_id == 1
            else f"plugin://plugin.video.elementum/show/{tmdb_id}/seasons"
        )
        add_menu_item(
            f"[COLOR deepskyblue][B][ĐA TRACKER] Quét thêm bản khác của \"{title}\" trên 45 Tracker UNIT3D[/B][/COLOR]",
            el_url,
            is_folder=True,
            plot="Gọi Elementum Burst tìm kiếm đồng thời trên toàn bộ 45 Private Tracker UNIT3D đã bật.",
        )

    xbmcplugin.setContent(HANDLE, "movies" if category_id == 1 else "episodes")
    xbmcplugin.endOfDirectory(HANDLE, cacheToDisc=True)


def action_search():
    kb = xbmc.Keyboard("", "Tìm kiếm tên phim hoặc mã TMDB ID trên VietMediaF")
    kb.doModal()
    if not kb.isConfirmed():
        xbmcplugin.endOfDirectory(HANDLE, succeeded=False)
        return
    query = (kb.getText() or "").strip()
    if not query:
        xbmcplugin.endOfDirectory(HANDLE, succeeded=False)
        return
    action_browse({"preset": "search", "page": 1, "query": query})


def action_play(params):
    download_link = params.get("download_link") or ""
    tmdb_id = int(params.get("tmdb_id") or 0)
    category_id = int(params.get("category_id") or 1)
    title = params.get("title") or "VietMediaF Stream"

    if not download_link:
        notify("VietMediaF", "Không tìm thấy link tải Torrent.", xbmcgui.NOTIFICATION_ERROR)
        xbmcplugin.setResolvedUrl(HANDLE, False, xbmcgui.ListItem())
        return

    if not has_addon("plugin.video.elementum"):
        if not check_and_install_elementum(force_interactive=True):
            xbmcplugin.setResolvedUrl(HANDLE, False, xbmcgui.ListItem())
            return

    enable_addon("plugin.video.elementum")
    media_type = "movie" if category_id == 1 else "episode"
    el_params = {"uri": download_link, "type": media_type}
    if tmdb_id > 0:
        el_params["tmdb"] = str(tmdb_id)

    elementum_play_url = f"plugin://plugin.video.elementum/play?{urllib.parse.urlencode(el_params)}"
    log(f"Playing via Elementum: {elementum_play_url}")

    li = xbmcgui.ListItem(label=title, path=elementum_play_url)
    xbmcplugin.setResolvedUrl(HANDLE, True, li)


def router():
    query_str = sys.argv[2][1:] if len(sys.argv) > 2 and sys.argv[2].startswith("?") else ""
    params = dict(urllib.parse.parse_qsl(query_str))
    action = params.get("action", "main")

    if action == "main":
        action_main_menu()
    elif action == "browse":
        action_browse(params)
    elif action == "versions":
        action_versions(params)
    elif action == "search":
        action_search()
    elif action == "play":
        action_play(params)
    elif action == "set_api_key":
        action_set_api_key()
    elif action == "account_info":
        action_account_info()
    elif action == "install_elementum":
        check_and_install_elementum(force_interactive=True)
    elif action == "open_settings":
        ADDON.openSettings()
        sync_api_key_with_burst()
        xbmc.executebuiltin("Container.Refresh")
    else:
        action_main_menu()


if __name__ == "__main__":
    router()

