# -*- coding: utf-8 -*-

"""
Burst utilities
"""

import os
import re
import socket
from threading import Lock
from elementum.provider import get_setting
from .providers.definitions import definitions
from urllib.parse import urlparse
import xbmcgui
import xbmcaddon

ADDON = xbmcaddon.Addon()
ADDON_NAME = ADDON.getAddonInfo("name")
ADDON_PATH = ADDON.getAddonInfo("path")
ADDON_ICON = ADDON.getAddonInfo("icon")
if not ADDON_PATH:
    ADDON_PATH = '..'

# ISO 639-1 codes and English names for {languages:short} and {languages:long} keywords
LANGUAGES = {
    "en": "english", "ru": "russian", "uk": "ukrainian", "be": "belarusian", "de": "german", "fr": "french",
    "es": "spanish", "it": "italian", "pt": "portuguese", "pl": "polish", "nl": "dutch", "sv": "swedish",
    "no": "norwegian", "da": "danish", "fi": "finnish", "cs": "czech", "sk": "slovak", "hu": "hungarian",
    "ro": "romanian", "bg": "bulgarian", "hr": "croatian", "sr": "serbian", "sl": "slovenian", "el": "greek",
    "tr": "turkish", "he": "hebrew", "ar": "arabic", "fa": "persian", "hi": "hindi", "ja": "japanese",
    "ko": "korean", "zh": "chinese", "th": "thai", "vi": "vietnamese", "id": "indonesian", "lt": "lithuanian",
    "lv": "latvian", "et": "estonian", "ka": "georgian", "kk": "kazakh",
}

# Countries whose flags stand for the language in results, ie. Torrentio shows 🇬🇧 for English
LANGUAGE_COUNTRIES = {
    "en": "GB,US", "ru": "RU", "uk": "UA", "be": "BY", "de": "DE", "fr": "FR", "es": "ES,MX", "it": "IT", "pt": "PT,BR",
    "pl": "PL", "nl": "NL", "sv": "SE", "no": "NO", "da": "DK", "fi": "FI", "cs": "CZ", "sk": "SK", "hu": "HU",
    "ro": "RO", "bg": "BG", "hr": "HR", "sr": "RS", "sl": "SI", "el": "GR", "tr": "TR", "he": "IL", "ar": "SA",
    "fa": "IR", "hi": "IN", "ja": "JP", "ko": "KR", "zh": "CN,TW", "th": "TH", "vi": "VN", "id": "ID", "lt": "LT",
    "lv": "LV", "et": "EE", "ka": "GE", "kk": "KZ",
}


def language_flags(language):
    """ Flag emojis for a language code, ie. ['🇬🇧'] for 'en' """
    return [''.join(chr(0x1F1E6 + ord(c) - ord('A')) for c in country) for country in LANGUAGE_COUNTRIES.get(language, '').split(',') if country]


class Magnet:
    """ Magnet link parsing class

    Args:
        magnet (str): A magnet link string

    Attributes:
        info_hash (str): Info-hash from the magnet link
        name      (str): Name of torrent
        trackers (list): List of trackers in magnet link
    """
    def __init__(self, magnet):
        self.magnet = magnet + '&'

        info_hash = re.search(r'urn:btih:(\w+)&', self.magnet, re.IGNORECASE)
        self.info_hash = None
        if info_hash:
            self.info_hash = info_hash.group(1)

        name = re.search('dn=(.*?)&', self.magnet)
        self.name = None
        if name:
            self.name = name.group(1).replace('+', ' ').title()

        self.trackers = re.findall('tr=(.*?)&', self.magnet)


def get_domain(url):
    if "//" not in url:
        url = "http://" + url

    parsed_uri = urlparse(url)
    domain = '{uri.netloc}'.format(uri=parsed_uri)
    return domain


def get_protocol(url):
    if "https://" in url:
        return "https"
    elif "http://" in url:
        return "http"

    return None

def with_defaults(definition):
    if 'login_prerequest' not in definition:
        definition['login_prerequest'] = ''
    return definition

def use_opennic_dns():
    # use_opennic_dns is a sub-setting of use_custom_dns and defaults to true
    return get_setting("use_custom_dns", bool) and get_setting("use_opennic_dns", bool)


def get_alias(definition, alias):
    definition["alias"] = ""

    if alias:
        old_domain = ""
        for k in ["root_url", "base_url"]:
            domain = get_domain(definition[k])
            if domain:
                old_domain = domain
                break

        new_domain = get_domain(alias)
        protocol = get_protocol(alias)
        if old_domain and new_domain:
            definition["alias"] = new_domain
            definition["old_domain"] = old_domain

            # Replace all occurrences of old domain name with new one
            for k in definition:
                if isinstance(definition[k], str):
                    definition[k] = definition[k].replace(old_domain, new_domain)
                    if protocol:
                        definition[k] = definition[k].replace("http://", protocol + "://")
                        definition[k] = definition[k].replace("https://", protocol + "://")

            if "parser" in definition and definition["parser"]:
                for k in definition["parser"]:
                    if isinstance(definition["parser"][k], str):
                        definition["parser"][k] = definition["parser"][k].replace(old_domain, new_domain)
                        if protocol:
                            definition["parser"][k] = definition["parser"][k].replace("http://", protocol + "://")
                            definition["parser"][k] = definition["parser"][k].replace("https://", protocol + "://")

    return definition


def get_enabled_providers(method):
    """ Utility method to get all enabled provider IDs

    Returns:
        list: All available enabled provider IDs
    """
    results = []
    content_type_string = 'Shows'  # if method == 'season' or method == 'episode' or method == 'anime'
    content_type_int = '2'
    if method == 'general':
        content_type_string = 'All'
        content_type_int = '0'
    elif method == 'movie':
        content_type_string = 'Movies'
        content_type_int = '1'
    for provider in definitions:
        if 'enabled' in definitions[provider] and not definitions[provider]['enabled']:
            continue

        if 'custom' in definitions[provider] and definitions[provider]['custom']:
            results.append(provider)
        elif get_setting('use_%s' % provider, bool):
            contains = get_setting('%s_contains' % provider, choices=('All', 'Movies', 'Shows'))
            if not contains or contains == 'All' or contains == '0':  # treat absence of setting as All
                results.append(provider)
            elif contains == content_type_string or contains == content_type_int:
                results.append(provider)
    return results


def get_icon_path():
    """ Utility method to Burst's icon path

    Returns:
        str: Path to Burst's icon
    """
    return os.path.join(ADDON_PATH, 'icon.png')


def translation(id_value):
    """ Utility method to get translations

    Args:
        id_value (int): Code of translation to get

    Returns:
        str: Translated string
    """
    return ADDON.getLocalizedString(id_value)


def get_int(string):
    """ Utility method to convert a number contained in a string to an integer

    Args:
        string (str): Number contained in a string

    Returns:
        int: The number as an integer, or 0
    """
    if not string:
        return 0
    try:
        return int(string)
    except:
        pass
    # Counters on sites come with thousand separators, ie. "1,234", "1.234" or "1 234"
    # Only groups of exactly 3 digits count, so "5.0", "1.2K" or "10 20" are not glued into one number
    match = re.search(r'\d{1,3}(?:[,. ]\d{3})+(?!\d)|\d+', '%s' % string)
    return int(re.sub(r'\D', '', match.group(0))) if match else 0


def get_float(string):
    """ Utility method to convert a number contained in a string to a float

    Args:
        string (str): Number contained in a string

    Returns:
        float: The number as a float, or 0.0
    """
    if not string:
        return float(0)
    try:
        return float(string)
    except:
        try:
            cleaned = clean_number(string)
            floated = re.findall(r'[\d.]+', cleaned)[0]
            return float(floated)
        except:
            return float(0)


def size_int(size_txt):
    """ Utility method to convert a file size contained in a string to an integer of bytes

    Args:
        string (str): File size with suffix contained in a string, eg. ``1.21 GB``

    Returns:
        float: The number of bytes as a float, or 0.0
    """
    try:
        return float(size_txt)
    except:
        try:
            size_txt = size_txt.upper()
            size = get_float(size_txt)
            if 'K' in size_txt:
                size *= 1e3
            if 'M' in size_txt:
                size *= 1e6
            if 'G' in size_txt:
                size *= 1e9
            if 'T' in size_txt:
                size *= 1e12
            return size
        except:
            pass
    return 0


def clean_number(string):
    """ Utility method to clean up a number contained in a string to dot decimal format

    Args:
        string (str): Number contained in a string

    Returns:
        str: The formatted number as a string
    """
    comma = string.find(',')
    point = string.find('.')
    if comma > 0 and point > 0:
        if comma < point:
            string = string.replace(',', '')
        else:
            string = string.replace('.', '')
            string = string.replace(',', '.')
    elif comma > 0:
        string = string.replace(',', '.')
    return string


def clean_size(string):
    """ Utility method to remove unnecessary information from a file size string, eg. '6.5 GBytes' -> '6.5 GB'

    Args:
        string (str): File size string to clean up

    Returns:
        str: Cleaned up file size
    """
    if string:
        pos = string.rfind('B')
        if pos > 0:
            string = string[:pos] + 'B'
    else:
        string = ""
    return string


def sizeof(num, suffix='B'):
    """ Utility method to convert a file size in bytes to a human-readable format

    Args:
        num    (int): Number of bytes
        suffix (str): Suffix for 'bytes'

    Returns:
        str: The formatted file size as a string, eg. ``1.21 GB``
    """
    for unit in ['', 'K', 'M', 'G', 'T', 'P', 'E', 'Z']:
        if abs(num) < 1024.0:
            return "%3.1f %s%s" % (num, unit, suffix)
        num /= 1024.0
    return "%.1f %s%s" % (num, 'Y', suffix)


def notify(message, image=None, time=5000):
    """ Creates a notification dialog

    Args:
        message (str): The message to show in the dialog
        image   (str): Path to an icon for this dialog
        time    (int): How long to show the notification, in milliseconds
    """
    dialog = xbmcgui.Dialog()
    dialog.notification(ADDON_NAME, message, icon=image, sound=False, time=time)
    del dialog


provider_errors = []
provider_errors_lock = Lock()


def add_error(message):
    """ Stores a provider error for the current search, avoiding duplicates

    Args:
        message (str): The error message to store
    """
    with provider_errors_lock:
        if message not in provider_errors:
            provider_errors.append(message)


def get_errors():
    """ Returns the provider errors collected during the current search

    Returns:
        list: Stored error messages
    """
    with provider_errors_lock:
        return list(provider_errors)


def clear_errors():
    """ Clears the provider errors collected during the previous search """
    with provider_errors_lock:
        provider_errors[:] = []


def encode_dict(dict_in, charset='utf8'):
    """ Encodes dict values to the given charset

    Args:
        dict_in (dict): Input dictionary with str values

    Returns:
        dict: Output dictionary with encoded values
    """
    try:
        dict_out = {}
        for k, v in dict_in.items():
            if isinstance(v, bytes):
                v = v.decode('utf8')
            if isinstance(v, str):
                v = v.encode(charset)
            dict_out[k] = v
        return dict_out
    except:
        return dict_in

def domain_matches(host, cookie_domain):
    """ Checks if cookie domain applies to the host, ie. '.example.com' applies to 'www.example.com'

    Args:
        host          (str): Host name, port is ignored
        cookie_domain (str): Domain of the cookie

    Returns:
        bool: True if cookie can be sent to the host, False otherwise
    """
    host = host.split(':')[0].lower()
    cookie_domain = cookie_domain.lstrip('.').lower()
    return bool(cookie_domain) and (host == cookie_domain or host.endswith('.' + cookie_domain))


def is_ipv4_address(string_ip):
    """ Checks if a string is a valid IPv4 address

    Args:
        string_ip (str): String to check

    Returns:
        bool: True if string is a valid IPv4 address, False otherwise
    """
    try:
        socket.inet_aton(string_ip)
    except socket.error:
        return False
    return True
