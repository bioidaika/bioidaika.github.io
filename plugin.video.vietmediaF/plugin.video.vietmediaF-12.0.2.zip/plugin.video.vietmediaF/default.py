# -*- coding: utf-8 -*-
import json
import os
import random
import re
import sqlite3
import sys
import time
import urllib.parse
import xml.etree.ElementTree as ET
import zipfile
from collections import OrderedDict
from concurrent.futures import ThreadPoolExecutor

import requests
import xbmc
import xbmcaddon
import xbmcgui
import xbmcplugin
import xbmcvfs

ADDON_ID = "plugin.video.vietmediaF"
ADDON = xbmcaddon.Addon(ADDON_ID)
ADDON_NAME = ADDON.getAddonInfo("name")
ADDON_PATH = ADDON.getAddonInfo("path")
ADDON_ICON = os.path.join(ADDON_PATH, "icon.png")
ADDON_FANART = os.path.join(ADDON_PATH, "fanart.png")

HANDLE = int(sys.argv[1]) if len(sys.argv) > 1 and sys.argv[1].isdigit() else -1
BASE_URL = sys.argv[0] if len(sys.argv) > 0 else f"plugin://{ADDON_ID}/"

HTTP_TIMEOUT = 15
SESSION = requests.Session()
SESSION.headers.update({
    "User-Agent": "VietMediaF-Kodi/12.0.2 (+https://tracker.vietmediaf.store)",
    "Accept": "application/json",
})

# Elementum's built-in TMDB API keys & endpoints (from elgatito/elementum/tmdb/tmdb.go)
TMDB_API_KEYS = [
    "8cf43ad9c085135b9479ad5cf6bbcbda",
    "ae4bd1b6fce2a5648671bfc171d15ba4",
    "29a551a65eef108dd01b46e27eb0554a",
]
TMDB_API_BASE = "https://api.tmdb.org/3"
TMDB_IMG_BASE = "https://image.tmdb.org/t/p/"
TMDB_CACHE_TTL = 7 * 24 * 3600  # 7 days

# Estuary Skin ViewMode IDs for Movies / TV Shows
VIEW_MODE_MAP = {
    "0": None,   # Tự động (Nhớ theo Kodi)
    "1": "54",   # InfoWall (Lưới Poster + Thông tin chi tiết)
    "2": "500",  # Wall (Lưới Poster toàn màn hình)
    "3": "51",   # Poster (Trượt ngang + Fanart)
    "4": "53",   # Shift (Trượt Poster lớn)
    "5": "55",   # WideList (Danh sách rộng)
}


def translate_path(path):
    if hasattr(xbmcvfs, "translatePath"):
        return xbmcvfs.translatePath(path)
    return xbmc.translatePath(path)


def get_Kodi_major_version():
    try:
        ver = xbmc.getInfoLabel("System.BuildVersion")
        return int(ver.split(".")[0])
    except Exception:
        return 20


KODI_VERSION = get_Kodi_major_version()


def log(msg, level=xbmc.LOGINFO):
    xbmc.log(f"[VietMediaF] {msg}", level)


def notify(title, message, icon=None, duration=4000):
    xbmcgui.Dialog().notification(title, message, icon or ADDON_ICON, duration)


def build_url(**kwargs):
    clean = {k: str(v) for k, v in kwargs.items() if v is not None and v != ""}
    return f"{BASE_URL}?{urllib.parse.urlencode(clean)}"


def get_tracker_url():
    url = (ADDON.getSetting("tracker_url") or "https://tracker.vietmediaf.store").strip().rstrip("/")
    return url or "https://tracker.vietmediaf.store"


def get_repo_url():
    url = (ADDON.getSetting("repo_url") or "https://kodi.vietmediaf.store").strip().rstrip("/")
    return url or "https://kodi.vietmediaf.store"


def get_per_page():
    idx = ADDON.getSetting("per_page") or "1"
    mapping = {"0": 25, "1": 50, "2": 100}
    return mapping.get(str(idx), 50)


def has_addon(addon_id):
    if xbmc.getCondVisibility(f"System.HasAddon({addon_id})"):
        return True
    addons_dir = translate_path("special://home/addons/")
    return os.path.isdir(os.path.join(addons_dir, addon_id))


def enable_addon(addon_id):
    try:
        payload = {
            "jsonrpc": "2.0",
            "id": 1,
            "method": "Addons.SetAddonEnabled",
            "params": {"addonid": addon_id, "enabled": True},
        }
        xbmc.executeJSONRPC(json.dumps(payload))
    except Exception as e:
        log(f"Failed to enable addon {addon_id}: {e}", xbmc.LOGWARNING)


def sync_api_key_with_burst(explicit_key=None):
    """Synchronize VietMediaF API key between plugin.video.vietmediaF and script.elementum.burst."""
    vmf_key = (explicit_key if explicit_key is not None else ADDON.getSetting("api_key") or "").strip()
    if explicit_key is not None:
        ADDON.setSetting("api_key", vmf_key)

    try:
        if has_addon("script.elementum.burst"):
            enable_addon("script.elementum.burst")
            burst = xbmcaddon.Addon("script.elementum.burst")
            burst_key = (burst.getSetting("vietmediaf_passkey") or "").strip()
            if vmf_key and vmf_key != burst_key:
                burst.setSetting("vietmediaf_passkey", vmf_key)
                burst.setSetting("use_vietmediaf", "true")
            elif burst_key and not vmf_key:
                ADDON.setSetting("api_key", burst_key)
                vmf_key = burst_key
    except Exception as e:
        log(f"Burst API key sync fallback: {e}", xbmc.LOGDEBUG)
        try:
            burst_data_dir = translate_path("special://profile/addon_data/script.elementum.burst")
            os.makedirs(burst_data_dir, exist_ok=True)
            settings_path = os.path.join(burst_data_dir, "settings.xml")
            if os.path.isfile(settings_path):
                tree = ET.parse(settings_path)
                root = tree.getroot()
            else:
                root = ET.Element("settings", version="2")
                tree = ET.ElementTree(root)

            if vmf_key:
                _set_xml_setting(root, "vietmediaf_passkey", vmf_key)
                _set_xml_setting(root, "use_vietmediaf", "true")
                tree.write(settings_path, encoding="utf-8", xml_declaration=True)
        except Exception as inner_e:
            log(f"Burst XML settings sync error: {inner_e}", xbmc.LOGWARNING)

    return vmf_key


def _set_xml_setting(root, setting_id, value):
    for elem in root.findall("setting"):
        if elem.attrib.get("id") == setting_id:
            elem.text = str(value)
            if "default" in elem.attrib:
                del elem.attrib["default"]
            return
    new_elem = ET.SubElement(root, "setting", id=setting_id)
    new_elem.text = str(value)


def format_size(num_bytes):
    try:
        size = float(num_bytes or 0)
    except (ValueError, TypeError):
        return "0 B"
    for unit in ["B", "KB", "MB", "GB", "TB"]:
        if size < 1024.0 or unit == "TB":
            return f"{size:.2f} {unit}" if unit in ("GB", "TB") else f"{size:.0f} {unit}"
        size /= 1024.0
    return f"{size:.2f} TB"


def detect_audio_badges(name):
    upper = (name or "").upper()
    badges = []
    if "VIE DUB" in upper or "VIEDUB" in upper or "THUYẾT MINH" in upper or "LỒNG TIẾNG" in upper:
        badges.append("[COLOR lime]ViE DUB[/COLOR]")
    elif re.search(r"\bVIE\b", upper) or "VIETSUB" in upper or "SUB VIET" in upper:
        badges.append("[COLOR lime]ViE[/COLOR]")
    if "ATMOS" in upper:
        badges.append("[COLOR deepskyblue]Atmos[/COLOR]")
    if "DV" in upper or "DOLBY VISION" in upper or "DOVI" in upper:
        badges.append("[COLOR magenta]DV[/COLOR]")
    elif "HDR10+" in upper:
        badges.append("[COLOR violet]HDR10+[/COLOR]")
    elif "HDR" in upper:
        badges.append("[COLOR violet]HDR[/COLOR]")
    return " ".join(badges)


def clean_release_title(name):
    if not name:
        return "Unknown"
    cleaned = re.sub(r"^\[[^\]]+\]\s*", "", name)
    match = re.match(r"^(.+?)\s+((?:19|20)\d{2})\b", cleaned)
    if match:
        return match.group(1).replace(".", " ").strip()
    match_se = re.match(r"^(.+?)\s+S\d{1,2}(?:E\d{1,3})?\b", cleaned, re.IGNORECASE)
    if match_se:
        return match_se.group(1).replace(".", " ").strip()
    return cleaned


def parse_season_episode_from_name(name):
    if not name:
        return 0, 0
    m = re.search(r"\bS(\d{1,2})E(\d{1,3})\b", name, re.IGNORECASE)
    if m:
        return int(m.group(1)), int(m.group(2))
    m_s = re.search(r"\b(?:S|Season[\s\.]?)(\d{1,2})\b", name, re.IGNORECASE)
    if m_s:
        return int(m_s.group(1)), 0
    return 0, 0


# ==============================================================================
# ELEMENTUM INFOTAG HELPER & LIST RENDERER (Ported from plugin.video.elementum)
# ==============================================================================
class InfoTagHelper(object):
    """Exact port of Elementum's Kodi 20+ InfoTagVideo helper."""

    LISTITEM_INFO_KEYS = ("count", "size", "overlay", "date")

    @staticmethod
    def _int(value):
        try:
            return int(value)
        except (TypeError, ValueError):
            try:
                return int(float(value))
            except (TypeError, ValueError):
                return 0

    @staticmethod
    def _float(value):
        try:
            return float(value)
        except (TypeError, ValueError):
            return 0.0

    @staticmethod
    def _votes(value):
        return int("".join(c for c in str(value) if c.isdigit()) or 0)

    @staticmethod
    def _str(value):
        return value if isinstance(value, str) else str(value or "")

    @staticmethod
    def _list(value):
        if isinstance(value, (list, tuple)):
            return [InfoTagHelper._str(v) for v in value if v]
        if isinstance(value, str):
            if " / " in value:
                return [x.strip() for x in value.split(" / ") if x.strip()]
            return [x.strip() for x in value.split(",") if x.strip()]
        return []

    @classmethod
    def apply_video(cls, list_item, info_tag, labels):
        rest = {}
        lowered = {key.lower(): value for key, value in labels.items() if value is not None}
        for key, value in lowered.items():
            if key in cls.LISTITEM_INFO_KEYS:
                rest[key] = value
            elif key == "rating":
                info_tag.setRating(cls._float(value), cls._votes(lowered.get("votes", 0)))
            elif key == "votes" and "rating" in lowered:
                continue
            elif key in cls.VIDEO_INFO_SETTERS:
                setter, convert = cls.VIDEO_INFO_SETTERS[key]
                try:
                    getattr(info_tag, setter)(convert(value))
                except Exception:
                    pass
        if rest:
            try:
                list_item.setInfo("video", rest)
            except Exception:
                pass

    @staticmethod
    def apply_cast(info_tag, castmembers):
        actors = []
        for castmember in castmembers:
            name = (castmember.get("name") or "").strip()
            if not name:
                continue
            order = InfoTagHelper._int(castmember.get("order", -1))
            actors.append(
                xbmc.Actor(
                    name=name,
                    role=InfoTagHelper._str(castmember.get("role") or ""),
                    thumbnail=InfoTagHelper._str(castmember.get("thumbnail") or ""),
                    order=order,
                )
            )
        if actors:
            try:
                info_tag.setCast(actors)
            except Exception:
                pass

    @staticmethod
    def apply_stream_info(info_tag, stream_info):
        for type_, values in stream_info.items():
            if not isinstance(values, dict):
                continue
            try:
                if type_ == "video":
                    info_tag.addVideoStream(
                        xbmc.VideoStreamDetail(
                            width=int(values.get("width", 0)),
                            height=int(values.get("height", 0)),
                            aspect=float(values.get("aspect", 0.0)),
                            duration=int(values.get("duration", 0)),
                            codec=str(values.get("codec", "")),
                            language=str(values.get("language", "")),
                        )
                    )
                elif type_ == "audio":
                    info_tag.addAudioStream(
                        xbmc.AudioStreamDetail(
                            language=str(values.get("language", "")),
                            codec=str(values.get("codec", "")),
                            channels=int(values.get("channels", -1)),
                        )
                    )
                elif type_ == "subtitle":
                    info_tag.addSubtitleStream(
                        xbmc.SubtitleStreamDetail(
                            language=str(values.get("language", "")),
                        )
                    )
            except Exception:
                pass


InfoTagHelper.VIDEO_INFO_SETTERS = {
    "dbid": ("setDbId", InfoTagHelper._int),
    "year": ("setYear", InfoTagHelper._int),
    "episode": ("setEpisode", InfoTagHelper._int),
    "season": ("setSeason", InfoTagHelper._int),
    "sortepisode": ("setSortEpisode", InfoTagHelper._int),
    "sortseason": ("setSortSeason", InfoTagHelper._int),
    "top250": ("setTop250", InfoTagHelper._int),
    "tracknumber": ("setTrackNumber", InfoTagHelper._int),
    "userrating": ("setUserRating", InfoTagHelper._int),
    "playcount": ("setPlaycount", InfoTagHelper._int),
    "genre": ("setGenres", InfoTagHelper._list),
    "country": ("setCountries", InfoTagHelper._list),
    "director": ("setDirectors", InfoTagHelper._list),
    "mpaa": ("setMpaa", InfoTagHelper._str),
    "plot": ("setPlot", InfoTagHelper._str),
    "plotoutline": ("setPlotOutline", InfoTagHelper._str),
    "title": ("setTitle", InfoTagHelper._str),
    "originaltitle": ("setOriginalTitle", InfoTagHelper._str),
    "sorttitle": ("setSortTitle", InfoTagHelper._str),
    "duration": ("setDuration", InfoTagHelper._int),
    "studio": ("setStudios", InfoTagHelper._list),
    "tagline": ("setTagLine", InfoTagHelper._str),
    "writer": ("setWriters", InfoTagHelper._list),
    "tvshowtitle": ("setTvShowTitle", InfoTagHelper._str),
    "premiered": ("setPremiered", InfoTagHelper._str),
    "status": ("setTvShowStatus", InfoTagHelper._str),
    "set": ("setSet", InfoTagHelper._str),
    "imdbnumber": ("setIMDBNumber", InfoTagHelper._str),
    "code": ("setProductionCode", InfoTagHelper._str),
    "aired": ("setFirstAired", InfoTagHelper._str),
    "votes": ("setVotes", InfoTagHelper._votes),
    "trailer": ("setTrailer", InfoTagHelper._str),
    "mediatype": ("setMediaType", InfoTagHelper._str),
}


# ==============================================================================
# TMDB METADATA & ARTWORK ENGINE (Replicates Elementum's tmdb/movie.go & show.go)
# ==============================================================================
def _get_tmdb_cache_db():
    profile_dir = translate_path(f"special://profile/addon_data/{ADDON_ID}")
    os.makedirs(profile_dir, exist_ok=True)
    db_path = os.path.join(profile_dir, "tmdb_cache_v1.sqlite3")
    conn = sqlite3.connect(db_path, timeout=10)
    conn.execute(
        "CREATE TABLE IF NOT EXISTS tmdb_cache ("
        "cache_key TEXT PRIMARY KEY, "
        "payload TEXT, "
        "updated_at INTEGER)"
    )
    return conn


def _tmdb_img(path, size="w780"):
    if not path:
        return ""
    return f"{TMDB_IMG_BASE}{size}{path}"


def _pick_localized_images(images_list, size, prefer_no_text=False):
    """Replicate Elementum's GetLocalizedImages logic from tmdb/tmdb.go."""
    if not images_list:
        return "", []
    vi_imgs = []
    en_imgs = []
    null_imgs = []
    other_imgs = []
    for img in images_list:
        fp = img.get("file_path")
        if not fp:
            continue
        url = _tmdb_img(fp, size)
        lang = (img.get("iso_639_1") or "").lower()
        if not lang or lang == "xx":
            null_imgs.append(url)
        elif lang == "vi":
            vi_imgs.append(url)
        elif lang == "en":
            en_imgs.append(url)
        else:
            other_imgs.append(url)

    if prefer_no_text:
        ordered = null_imgs + en_imgs + vi_imgs + other_imgs
    else:
        ordered = vi_imgs + en_imgs + null_imgs + other_imgs
    primary = ordered[0] if ordered else ""
    return primary, ordered


def _parse_tmdb_entity_to_elementum_dict(data, media_type="movie"):
    """Convert raw TMDB Movie/TV JSON into Elementum's exact ListItem dict structure."""
    is_movie = media_type == "movie"
    tmdb_id = data.get("id") or 0

    raw_title = data.get("title") if is_movie else data.get("name")
    orig_title = data.get("original_title") if is_movie else data.get("original_name")
    raw_overview = (data.get("overview") or "").strip()
    raw_tagline = (data.get("tagline") or "").strip()

    # Check translations for Vietnamese / English fallback (exact Elementum logic)
    vi_title, en_title = "", ""
    vi_overview, en_overview = "", ""
    vi_tagline, en_tagline = "", ""
    for tr in (data.get("translations") or {}).get("translations") or []:
        iso = (tr.get("iso_639_1") or "").lower()
        tr_data = tr.get("data") or {}
        t_val = (tr_data.get("title") if is_movie else tr_data.get("name")) or ""
        o_val = (tr_data.get("overview") or "").strip()
        tg_val = (tr_data.get("tagline") or "").strip()
        if iso == "vi":
            if t_val:
                vi_title = t_val
            if o_val:
                vi_overview = o_val
            if tg_val:
                vi_tagline = tg_val
        elif iso == "en":
            if t_val:
                en_title = t_val
            if o_val:
                en_overview = o_val
            if tg_val:
                en_tagline = tg_val

    title_vi = vi_title or raw_title or en_title or orig_title or "Unknown"
    title_orig = orig_title or en_title or raw_title or title_vi
    overview = vi_overview or raw_overview or en_overview or ""
    tagline = vi_tagline or raw_tagline or en_tagline or ""

    release_date = (data.get("release_date") if is_movie else data.get("first_air_date")) or ""
    year = 0
    if release_date and len(release_date) >= 4 and release_date[:4].isdigit():
        year = int(release_date[:4])

    runtime = 0
    if is_movie:
        runtime = int(data.get("runtime") or 0) * 60
    else:
        ep_runtimes = data.get("episode_run_time") or []
        if ep_runtimes:
            runtime = int(ep_runtimes[-1] or 0) * 60

    vote_average = float(data.get("vote_average") or 0.0)
    vote_count = int(data.get("vote_count") or 0)

    ext_ids = data.get("external_ids") or {}
    imdb_id = data.get("imdb_id") or ext_ids.get("imdb_id") or ""

    genres = [g.get("name") for g in (data.get("genres") or []) if g.get("name")]
    studios = [c.get("name") for c in (data.get("production_companies") or []) if c.get("name")]
    if not is_movie:
        networks = [n.get("name") for n in (data.get("networks") or []) if n.get("name")]
        if networks:
            studios = networks + [s for s in studios if s not in networks]
    countries = [c.get("name") for c in (data.get("production_countries") or []) if c.get("name")]

    # MPAA / Certification
    mpaa = ""
    if is_movie:
        for r in ((data.get("release_dates") or {}).get("results") or []):
            if (r.get("iso_3166_1") or "").upper() in ("VN", "US"):
                for rd in r.get("release_dates") or []:
                    if rd.get("certification"):
                        mpaa = rd["certification"]
                        break
                if mpaa:
                    break
    else:
        for r in ((data.get("content_ratings") or {}).get("results") or []):
            if (r.get("iso_3166_1") or "").upper() in ("VN", "US") and r.get("rating"):
                mpaa = r["rating"]
                break

    # Trailer
    trailer = ""
    for vid in ((data.get("videos") or {}).get("results") or []):
        if vid.get("site") == "YouTube" and vid.get("type") == "Trailer" and vid.get("key"):
            trailer = f"plugin://plugin.video.youtube/?action=play_video&videoid={vid['key']}"
            break

    # Credits (Cast, Directors, Writers)
    credits = data.get("credits") or {}
    castmembers = []
    for idx, c in enumerate((credits.get("cast") or [])[:20]):
        c_name = (c.get("name") or "").strip()
        if not c_name:
            continue
        castmembers.append({
            "name": c_name,
            "role": c.get("character") or "",
            "thumbnail": _tmdb_img(c.get("profile_path"), "w185") if c.get("profile_path") else "",
            "order": int(c.get("order", idx)),
        })

    directors = []
    writers = []
    for crew in credits.get("crew") or []:
        c_name = (crew.get("name") or "").strip()
        if not c_name:
            continue
        if crew.get("job") == "Director" and c_name not in directors:
            directors.append(c_name)
        elif crew.get("department") == "Writing" and c_name not in writers:
            writers.append(c_name)
    if not is_movie and not directors:
        for creator in data.get("created_by") or []:
            if creator.get("name") and creator["name"] not in directors:
                directors.append(creator["name"])

    # Artworks (Poster, Fanart, Fanarts list, Landscape with text, ClearLogo)
    images = data.get("images") or {}
    default_poster = _tmdb_img(data.get("poster_path"), "w780")
    default_fanart = _tmdb_img(data.get("backdrop_path"), "w1280")
    default_thumb = _tmdb_img(data.get("backdrop_path"), "w780") or default_poster

    loc_poster, all_posters = _pick_localized_images(images.get("posters"), "w780", prefer_no_text=False)
    _, fanarts_no_text = _pick_localized_images(images.get("backdrops"), "w1280", prefer_no_text=True)
    loc_landscape, _ = _pick_localized_images(
        [b for b in (images.get("backdrops") or []) if b.get("iso_639_1")],
        "w780",
        prefer_no_text=False,
    )
    loc_logo, _ = _pick_localized_images(images.get("logos"), "w500", prefer_no_text=False)

    poster = loc_poster or default_poster or ADDON_ICON
    fanart = (fanarts_no_text[0] if fanarts_no_text else "") or default_fanart or ADDON_FANART
    landscape = loc_landscape or default_thumb or fanart

    art = {
        "poster": poster,
        "fanart": fanart,
        "thumb": default_thumb or poster,
        "icon": default_thumb or poster,
        "landscape": landscape,
    }
    if not is_movie:
        art["tvshowposter"] = poster
    if loc_logo:
        art["clearlogo"] = loc_logo
    if fanarts_no_text:
        art["fanarts"] = fanarts_no_text[:8]
    if all_posters:
        art["available_posters"] = all_posters[:6]

    spoken = data.get("spoken_languages") or []
    audio_lang = spoken[0].get("iso_639_1", "") if spoken else ""

    properties = {}
    status = ""
    if not is_movie:
        seasons_count = len([s for s in (data.get("seasons") or []) if (s.get("season_number") or 0) > 0])
        if not seasons_count:
            seasons_count = int(data.get("number_of_seasons") or 0)
        episodes_count = int(data.get("number_of_episodes") or 0)
        if seasons_count > 0:
            properties["TotalSeasons"] = str(seasons_count)
        if episodes_count > 0:
            properties["TotalEpisodes"] = str(episodes_count)
        status = "Continuing" if data.get("in_production") else "Discontinued"

    return {
        "tmdb_id": tmdb_id,
        "media_type": "movie" if is_movie else "tvshow",
        "title_vi": title_vi,
        "title_orig": title_orig,
        "year": year,
        "release_date": release_date,
        "overview": overview,
        "tagline": tagline,
        "duration": runtime,
        "rating": vote_average,
        "votes": vote_count,
        "imdb_id": imdb_id,
        "mpaa": mpaa,
        "genres": genres,
        "studios": studios,
        "countries": countries,
        "directors": directors,
        "writers": writers,
        "trailer": trailer,
        "status": status,
        "audio_lang": audio_lang,
        "art": art,
        "castmembers": castmembers,
        "properties": properties,
    }


def _fetch_single_tmdb(media_type, tmdb_id):
    endpoint = "movie" if media_type == "movie" else "tv"
    append = (
        "credits,images,videos,translations,external_ids,release_dates"
        if media_type == "movie"
        else "credits,images,videos,translations,external_ids,content_ratings"
    )
    api_key = random.choice(TMDB_API_KEYS)
    url = f"{TMDB_API_BASE}/{endpoint}/{tmdb_id}"
    params = {
        "api_key": api_key,
        "append_to_response": append,
        "include_image_language": "vi,en,null",
        "include_video_language": "vi,en,null",
        "language": "vi-VN",
    }
    try:
        resp = SESSION.get(url, params=params, timeout=8)
        if resp.status_code == 200:
            return _parse_tmdb_entity_to_elementum_dict(resp.json(), media_type=media_type)
    except Exception as e:
        log(f"TMDB fetch failed for {media_type}/{tmdb_id}: {e}", xbmc.LOGDEBUG)
    return None


def fetch_tmdb_metadata_batch(requests_list):
    """Fetch TMDB metadata for a list of (media_type, tmdb_id) tuples using SQLite cache + ThreadPoolExecutor."""
    if not requests_list:
        return {}

    unique_reqs = []
    seen = set()
    for mtype, tid in requests_list:
        if tid and tid > 0 and (mtype, tid) not in seen:
            seen.add((mtype, tid))
            unique_reqs.append((mtype, tid))

    if not unique_reqs:
        return {}

    results = {}
    missing = []
    now_ts = int(time.time())

    try:
        conn = _get_tmdb_cache_db()
        cur = conn.cursor()
        for mtype, tid in unique_reqs:
            ckey = f"{mtype}:{tid}"
            cur.execute("SELECT payload, updated_at FROM tmdb_cache WHERE cache_key = ?", (ckey,))
            row = cur.fetchone()
            if row and (now_ts - int(row[1] or 0)) < TMDB_CACHE_TTL:
                try:
                    results[(mtype, tid)] = json.loads(row[0])
                    continue
                except Exception:
                    pass
            missing.append((mtype, tid))
        conn.close()
    except Exception as e:
        log(f"TMDB cache read error: {e}", xbmc.LOGWARNING)
        missing = unique_reqs

    if missing:
        fetched = {}
        with ThreadPoolExecutor(max_workers=12) as pool:
            future_map = {pool.submit(_fetch_single_tmdb, mtype, tid): (mtype, tid) for mtype, tid in missing}
            for fut, key in future_map.items():
                try:
                    data = fut.result()
                    if data:
                        fetched[key] = data
                        results[key] = data
                except Exception:
                    pass

        if fetched:
            try:
                conn = _get_tmdb_cache_db()
                with conn:
                    for (mtype, tid), data in fetched.items():
                        ckey = f"{mtype}:{tid}"
                        conn.execute(
                            "INSERT OR REPLACE INTO tmdb_cache (cache_key, payload, updated_at) VALUES (?, ?, ?)",
                            (ckey, json.dumps(data, ensure_ascii=False), now_ts),
                        )
                conn.close()
            except Exception as e:
                log(f"TMDB cache write error: {e}", xbmc.LOGWARNING)

    return results


def format_display_title(tmdb_meta, fallback_title):
    if not tmdb_meta:
        return fallback_title
    mode = ADDON.getSetting("title_lang") or "0"
    t_vi = tmdb_meta.get("title_vi") or fallback_title
    t_orig = tmdb_meta.get("title_orig") or t_vi
    if mode == "1":
        return t_orig
    if mode == "2" and t_vi.lower() != t_orig.lower():
        return f"{t_vi} ({t_orig})"
    return t_vi


def create_elementum_listitem(item_dict):
    """Build an xbmcgui.ListItem using Elementum's exact navigation.py & InfoTagHelper pipeline."""
    label = item_dict.get("label") or ""
    label2 = item_dict.get("label2") or ""
    icon = item_dict.get("icon") or ADDON_ICON
    thumb = item_dict.get("thumbnail") or icon

    li = xbmcgui.ListItem(label=label, label2=label2, offscreen=True)
    li.setArt({"icon": icon, "thumb": thumb})

    video_info_tag = li.getVideoInfoTag() if KODI_VERSION >= 20 else None

    try:
        if item_dict.get("castmembers"):
            if KODI_VERSION >= 20 and video_info_tag:
                InfoTagHelper.apply_cast(video_info_tag, item_dict["castmembers"])
            else:
                li.setCast(item_dict["castmembers"])

        if item_dict.get("info"):
            info_copy = dict(item_dict["info"])
            if KODI_VERSION >= 20 and video_info_tag:
                InfoTagHelper.apply_video(li, video_info_tag, info_copy)
            else:
                li.setInfo("video", info_copy)

        if item_dict.get("stream_info"):
            if KODI_VERSION >= 20 and video_info_tag:
                InfoTagHelper.apply_stream_info(video_info_tag, item_dict["stream_info"])
            else:
                for type_, values in item_dict["stream_info"].items():
                    li.addStreamInfo(type_, values)

        if item_dict.get("uniqueids"):
            uids = {k: str(v) for k, v in item_dict["uniqueids"].items() if v}
            if uids:
                if KODI_VERSION >= 20 and video_info_tag:
                    video_info_tag.setUniqueIDs(uids)
                else:
                    li.setUniqueIDs(uids)

        if item_dict.get("art"):
            art = dict(item_dict["art"])
            fanarts = art.pop("fanarts", None)
            avail_posters = art.pop("available_posters", None)
            if fanarts:
                try:
                    li.setAvailableFanart([{"image": fa} for fa in fanarts])
                except Exception:
                    pass
            if avail_posters and KODI_VERSION >= 20 and video_info_tag:
                for p_url in avail_posters:
                    try:
                        video_info_tag.addAvailableArtwork(p_url, "poster")
                    except Exception:
                        pass
            li.setArt(art)
        else:
            li.setArt({"fanart": ADDON_FANART})

        if item_dict.get("context_menu"):
            li.addContextMenuItems(item_dict["context_menu"])

        li.setProperty("isPlayable", "true" if item_dict.get("is_playable") else "false")

        if item_dict.get("properties"):
            for k, v in item_dict["properties"].items():
                li.setProperty(str(k), str(v))
    except Exception as e:
        log(f"Could not initialize ListItem ({label}): {e}", xbmc.LOGWARNING)

    return li


def apply_elementum_sorting_and_view(content_type="movies"):
    """Register Elementum's exact sort methods, content_type, and optional ViewMode."""
    xbmcplugin.addSortMethod(HANDLE, xbmcplugin.SORT_METHOD_UNSORTED)
    if content_type:
        try:
            if content_type != "tvshows":
                xbmcplugin.addSortMethod(HANDLE, xbmcplugin.SORT_METHOD_LABEL_IGNORE_THE)
                xbmcplugin.addSortMethod(HANDLE, xbmcplugin.SORT_METHOD_VIDEO_YEAR)
            else:
                xbmcplugin.addSortMethod(HANDLE, xbmcplugin.SORT_METHOD_TITLE_IGNORE_THE)
                xbmcplugin.addSortMethod(HANDLE, xbmcplugin.SORT_METHOD_VIDEO_YEAR)

            xbmcplugin.addSortMethod(HANDLE, xbmcplugin.SORT_METHOD_VIDEO_RATING)
            xbmcplugin.addSortMethod(HANDLE, xbmcplugin.SORT_METHOD_DATE)
            xbmcplugin.addSortMethod(HANDLE, xbmcplugin.SORT_METHOD_GENRE)
        except Exception:
            pass
        xbmcplugin.setContent(HANDLE, content_type)


def trigger_configured_viewmode():
    vm_idx = ADDON.getSetting("view_mode") or "1"
    view_id = VIEW_MODE_MAP.get(str(vm_idx))
    if not view_id:
        return
    try:
        xbmc.executebuiltin(f"Container.SetViewMode({view_id})")
    except Exception as e:
        log(f"SetViewMode({view_id}) error: {e}", xbmc.LOGDEBUG)


# ==============================================================================
# TRACKER API & USER PROFILE
# ==============================================================================
def api_get(endpoint, params=None, api_key=None):
    key = sync_api_key_with_burst(api_key)
    if not key:
        return None, "Chưa cấu hình API Key"

    url = f"{get_tracker_url()}{endpoint}"
    headers = {"Authorization": f"Bearer {key}"}
    try:
        resp = SESSION.get(url, params=params, headers=headers, timeout=HTTP_TIMEOUT)
        if resp.status_code == 401:
            return None, "API Key không hợp lệ hoặc đã hết hạn (HTTP 401)."
        if resp.status_code == 403:
            return None, "API Key chưa được bật quyền (Scope) cho mục này (HTTP 403)."
        if resp.status_code != 200:
            return None, f"Lỗi máy chủ Tracker (HTTP {resp.status_code})."
        return resp.json(), None
    except requests.RequestException as e:
        log(f"API request failed ({url}): {e}", xbmc.LOGERROR)
        return None, f"Không thể kết nối tới {get_tracker_url()}: {e}"


def fetch_user_profile(api_key=None):
    data, err = api_get("/api/user", api_key=api_key)
    if err or not isinstance(data, dict):
        # Fallback check: if API key only has search/download scope (no user scope), test /api/torrents/filter
        if err and "403" in err:
            test_data, test_err = api_get("/api/torrents/filter", params={"perPage": 1}, api_key=api_key)
            if not test_err and isinstance(test_data, dict):
                return {
                    "username": "Thành viên VietMediaF",
                    "group": "API Key Hợp Lệ",
                    "uploaded": "N/A",
                    "downloaded": "N/A",
                    "ratio": "N/A",
                    "buffer": "N/A",
                    "seedbonus": "N/A",
                    "seeding": "N/A",
                    "leeching": "N/A",
                    "hit_and_runs": 0,
                    "scope_limited": True,
                }, None
        return None, err

    for byte_field in ("uploaded", "downloaded", "buffer"):
        val = data.get(byte_field)
        if val is None and byte_field == "buffer":
            data[byte_field] = "Inf"
        elif isinstance(val, (int, float)):
            data[byte_field] = format_size(val)
    if data.get("ratio") is None:
        data["ratio"] = "Inf"
    return data, None


def check_and_install_elementum(force_interactive=False):
    """Check if Elementum and Elementum Burst (v0.0.103+) are installed; offer 1-click installation."""
    has_el = has_addon("plugin.video.elementum")
    has_burst = has_addon("script.elementum.burst")
    burst_ver_ok = False
    if has_burst:
        try:
            ver = xbmcaddon.Addon("script.elementum.burst").getAddonInfo("version")
            parts = [int(x) for x in re.findall(r"\d+", ver)]
            burst_ver_ok = parts >= [0, 0, 103]
        except Exception:
            burst_ver_ok = True

    if has_el and has_burst and burst_ver_ok and not force_interactive:
        return True

    if not force_interactive and ADDON.getSetting("elementum_prompted") == "true" and has_el:
        return True

    ADDON.setSetting("elementum_prompted", "true")
    missing_desc = []
    if not has_el:
        missing_desc.append("• [B]Elementum[/B] (Trình phát P2P BitTorrent tốc độ cao)")
    if not has_burst or not burst_ver_ok:
        missing_desc.append("• [B]Elementum Burst v0.0.103[/B] (Tích hợp 45 Tracker UNIT3D + VietMediaF)")

    if not missing_desc and force_interactive:
        missing_desc.append("• [B]Cài đặt lại / Cập nhật bộ Elementum + Elementum Burst (45 Tracker UNIT3D)[/B]")

    msg = (
        "[COLOR gold][B]VietMediaF v12.0.2[/B][/COLOR] sử dụng engine [B]Elementum[/B] để phát trực tiếp "
        "phim 4K UHD / BluRay Remux từ [B]tracker.vietmediaf.store[/B] và 45 Tracker UNIT3D.\n\n"
        + "\n".join(missing_desc)
        + "\n\nBạn có muốn tự động tải về và kích hoạt ngay bây giờ không?"
    )
    if not xbmcgui.Dialog().yesno("Cài đặt Elementum & Burst", msg, nolabel="Để sau", yeslabel="Cài đặt ngay"):
        return False

    repo = get_repo_url()
    packages = [
        (
            "plugin.video.elementum",
            "Elementum P2P Engine (v0.1.119 - All Platforms)",
            [
                f"{repo}/plugin.video.elementum/plugin.video.elementum-0.1.119.zip",
                f"{repo}/plugin.video.elementum-0.1.119.zip",
                "https://github.com/elgatito/plugin.video.elementum/releases/download/v0.1.119/plugin.video.elementum-0.1.119.zip",
            ],
        ),
        (
            "script.elementum.burst",
            "Elementum Burst (v0.0.103 - 45 UNIT3D Trackers)",
            [
                f"{repo}/script.elementum.burst/script.elementum.burst-0.0.103.zip",
                f"{repo}/script.elementum.burst-0.0.103.zip",
                "https://github.com/bioidaika/script.elementum.burst/archive/refs/heads/master.zip",
            ],
        ),
        (
            "context.elementum",
            "Elementum Context Menu (v0.0.17)",
            [
                f"{repo}/context.elementum/context.elementum-0.0.17.zip",
                f"{repo}/context.elementum-0.0.17.zip",
                "https://github.com/elgatito/context.elementum/releases/download/v0.0.17/context.elementum-0.0.17.zip",
            ],
        ),
    ]

    addons_dir = translate_path("special://home/addons/")
    packages_dir = translate_path("special://home/addons/packages/")
    os.makedirs(packages_dir, exist_ok=True)

    progress = xbmcgui.DialogProgress()
    progress.create("VietMediaF — Cài đặt Elementum", "Đang chuẩn bị tải gói cài đặt...")

    installed_any = False
    for idx, (pkg_id, label, urls) in enumerate(packages):
        if progress.iscanceled():
            break
        pct = int((idx / len(packages)) * 100)
        progress.update(pct, f"Đang tải {label}...")

        zip_path = os.path.join(packages_dir, f"{pkg_id}.zip")
        downloaded = False
        for url in urls:
            try:
                with SESSION.get(url, stream=True, timeout=60) as r:
                    if r.status_code == 200:
                        with open(zip_path, "wb") as f:
                            for chunk in r.iter_content(chunk_size=65536):
                                if chunk:
                                    f.write(chunk)
                        downloaded = True
                        break
            except Exception as e:
                log(f"Download failed from {url}: {e}", xbmc.LOGWARNING)

        if not downloaded:
            log(f"Could not download package {pkg_id}", xbmc.LOGERROR)
            continue

        progress.update(pct + 15, f"Đang giải nén {label}...")
        try:
            with zipfile.ZipFile(zip_path, "r") as zf:
                names = zf.namelist()
                top_dir = names[0].split("/")[0] if names else ""
                zf.extractall(addons_dir)
                if top_dir and top_dir != pkg_id and top_dir.startswith(pkg_id):
                    extracted_dir = os.path.join(addons_dir, top_dir)
                    target_dir = os.path.join(addons_dir, pkg_id)
                    if os.path.isdir(extracted_dir):
                        import shutil
                        if os.path.isdir(target_dir):
                            shutil.rmtree(target_dir, ignore_errors=True)
                        shutil.move(extracted_dir, target_dir)
            enable_addon(pkg_id)
            installed_any = True
        except Exception as e:
            log(f"Failed to extract {pkg_id}: {e}", xbmc.LOGERROR)

    progress.update(100, "Đang cập nhật hệ thống Addon của Kodi...")
    xbmc.executebuiltin("UpdateLocalAddons")
    xbmc.sleep(1500)
    for pkg_id, _, _ in packages:
        enable_addon(pkg_id)
    sync_api_key_with_burst()
    progress.close()

    if installed_any:
        xbmcgui.Dialog().ok(
            "VietMediaF — Hoàn tất cài đặt",
            "Đã cài đặt và kích hoạt thành công [B]Elementum[/B] + [B]Elementum Burst (45 Tracker UNIT3D)[/B]!\n"
            "API Key VietMediaF của bạn cũng đã được đồng bộ tự động.",
        )
    return installed_any


def action_set_api_key():
    current_key = sync_api_key_with_burst()
    kb = xbmc.Keyboard(current_key, "Nhập API Key của bạn trên tracker.vietmediaf.store")
    kb.doModal()
    if not kb.isConfirmed():
        return
    new_key = (kb.getText() or "").strip()
    if not new_key:
        notify("VietMediaF", "API Key không được để trống.", xbmcgui.NOTIFICATION_WARNING)
        return

    sync_api_key_with_burst(new_key)
    profile, err = fetch_user_profile(new_key)
    if profile and profile.get("username"):
        if profile.get("scope_limited"):
            xbmcgui.Dialog().ok(
                "Kết nối VietMediaF Tracker thành công!",
                "API Key hợp lệ và đã được đồng bộ tự động sang Elementum Burst!\n"
                "(Mẹo: Bật thêm quyền 'View User' cho API Key trên web nếu muốn hiển thị số liệu Upload/Download/Ratio).",
            )
        else:
            xbmcgui.Dialog().ok(
                "Kết nối VietMediaF Tracker thành công!",
                f"Xin chào [COLOR lime][B]{profile.get('username')}[/B][/COLOR] ({profile.get('group', 'Member')})!\n"
                f"Upload: [B]{profile.get('uploaded', '0 B')}[/B]   |   Download: [B]{profile.get('downloaded', '0 B')}[/B]\n"
                f"Ratio: [B]{profile.get('ratio', '0')}[/B]   |   Điểm thưởng: [B]{profile.get('seedbonus', 0)} BON[/B]\n"
                "API Key đã được đồng bộ tự động sang Elementum Burst.",
            )
    else:
        xbmcgui.Dialog().ok(
            "Đã lưu API Key",
            f"Đã lưu API Key và đồng bộ sang Elementum Burst.\nLưu ý khi kiểm tra hồ sơ: {err or 'Không rõ'}",
        )
    xbmc.executebuiltin("Container.Refresh")


def action_account_info():
    key = sync_api_key_with_burst()
    if not key:
        action_set_api_key()
        return
    profile, err = fetch_user_profile(key)
    if not profile:
        if xbmcgui.Dialog().yesno(
            "Lỗi xác thực API Key",
            f"Không thể lấy thông tin tài khoản:\n{err}\n\nBạn có muốn nhập lại API Key không?",
        ):
            action_set_api_key()
        return

    lines = [
        f"• Tài khoản: [COLOR lime][B]{profile.get('username')}[/B][/COLOR]  —  Nhóm: [COLOR gold][B]{profile.get('group')}[/B][/COLOR]",
        f"• Đã tải lên (Upload): [COLOR green][B]{profile.get('uploaded')}[/B][/COLOR]  |  Đã tải xuống (Download): [COLOR orange][B]{profile.get('downloaded')}[/B][/COLOR]",
        f"• Tỉ lệ (Ratio): [COLOR cyan][B]{profile.get('ratio')}[/B][/COLOR]  |  Buffer: [B]{profile.get('buffer')}[/B]",
        f"• Điểm thưởng (Seedbonus): [COLOR yellow][B]{profile.get('seedbonus')} BON[/B][/COLOR]",
        f"• Đang Seeding: [COLOR lime][B]{profile.get('seeding')}[/B][/COLOR]  |  Đang Leeching: [B]{profile.get('leeching')}[/B]  |  Hit & Runs: [B]{profile.get('hit_and_runs')}[/B]",
    ]
    if xbmcgui.Dialog().yesno(
        "Thông tin tài khoản VietMediaF Tracker",
        "\n".join(lines),
        nolabel="Đóng",
        yeslabel="Đổi API Key",
    ):
        action_set_api_key()


def add_simple_menu_item(label, url, is_folder=True, icon=None, fanart=None, plot=""):
    li = xbmcgui.ListItem(label=label, offscreen=True)
    poster = icon or ADDON_ICON
    backdrop = fanart or ADDON_FANART
    li.setArt({
        "icon": poster,
        "thumb": poster,
        "poster": poster,
        "fanart": backdrop,
    })
    info = {"title": label, "plot": plot or label, "mediatype": "video"}
    if KODI_VERSION >= 20:
        InfoTagHelper.apply_video(li, li.getVideoInfoTag(), info)
    else:
        li.setInfo("video", info)
    xbmcplugin.addDirectoryItem(handle=HANDLE, url=url, listitem=li, isFolder=is_folder)


def action_main_menu():
    check_and_install_elementum(force_interactive=False)
    key = sync_api_key_with_burst()

    if key:
        profile, _ = fetch_user_profile(key)
        if profile and profile.get("username"):
            if profile.get("scope_limited"):
                acct_label = (
                    f"[COLOR lime][B][{profile.get('username')}][/B][/COLOR] "
                    f"([COLOR gold]Đã kết nối API Key[/COLOR]) — Nhấn để xem hoặc đổi API Key"
                )
            else:
                acct_label = (
                    f"[COLOR lime][B][{profile.get('username')}][/B][/COLOR] ([COLOR gold]{profile.get('group')}[/COLOR]) "
                    f"| Up: {profile.get('uploaded')} / Down: {profile.get('downloaded')} "
                    f"| Ratio: [COLOR cyan]{profile.get('ratio')}[/COLOR] "
                    f"| [COLOR yellow]{profile.get('seedbonus')} BON[/COLOR] "
                    f"| Seed: [COLOR lime]{profile.get('seeding')}[/COLOR]"
                )
            add_simple_menu_item(
                acct_label,
                build_url(action="account_info"),
                is_folder=False,
                plot="Xem chi tiết thống kê tài khoản VietMediaF Tracker hoặc đổi API Key.",
            )
        else:
            add_simple_menu_item(
                "[COLOR orange][B][!] API Key không hợp lệ hoặc mất kết nối — Nhấn để kiểm tra / nhập lại[/B][/COLOR]",
                build_url(action="set_api_key"),
                is_folder=False,
                plot="Kiểm tra hoặc nhập lại API Key từ https://tracker.vietmediaf.store",
            )
    else:
        add_simple_menu_item(
            "[COLOR yellow][B][API KEY] Nhập API Key VietMediaF Tracker (Bắt buộc để duyệt & tải phim)[/B][/COLOR]",
            build_url(action="set_api_key"),
            is_folder=False,
            plot="Lấy API Key trong mục Thiết lập -> API Key trên https://tracker.vietmediaf.store. Tự động đồng bộ với Elementum Burst.",
        )

    menu_entries = [
        ("[COLOR gold][HOT][/COLOR] [B]Phim Đề Cử (Featured Torrents)[/B]", "featured", "Danh sách phim đặc sắc được Ban Quản Trị VietMediaF đề cử (thường kèm Freeleech 100%)."),
        ("[COLOR cyan][MỚI][/COLOR] [B]Mới Cập Nhật (Tất Cả Phim)[/B]", "latest_all", "Toàn bộ Phim mới nhất vừa được upload lên VietMediaF Tracker."),
        ("[COLOR deepskyblue][PHIM LẺ][/COLOR] [B]Phim Lẻ Mới Nhất (Movies)[/B]", "movies_new", "Danh sách Phim Điện Ảnh (Movies) mới nhất, hiển thị Poster/Fanart/Diễn viên chuẩn Elementum."),
        ("[COLOR violet][PHIM BỘ][/COLOR] [B]Phim Bộ / Series Mới Nhất (TV Shows)[/B]", "tv_new", "Danh sách Phim Bộ / Series truyền hình mới nhất trên VietMediaF."),
        ("[COLOR lime][ViE DUB][/COLOR] [B]Phim Thuyết Minh / Lồng Tiếng[/B]", "vie_dub", "Tuyển tập phim có âm thanh Thuyết Minh hoặc Lồng Tiếng Việt chất lượng cao."),
        ("[COLOR lime][ViE SUB][/COLOR] [B]Phim Phụ Đề Tiếng Việt[/B]", "vie_sub", "Tuyển tập phim có Phụ Đề Tiếng Việt chuẩn trên VietMediaF Tracker."),
        ("[COLOR orange][FREELEECH][/COLOR] [B]Phim Miễn Phí 100% Dung Lượng Tải[/B]", "freeleech", "Tải và xem thoải mái không tính dung lượng Download, chỉ cộng Upload & Điểm thưởng BON!"),
        ("[COLOR magenta][4K UHD][/COLOR] [B]Phim 4K UHD / BluRay Remux / Dolby Vision[/B]", "uhd_4k", "Phim chất lượng siêu nét 2160p 4K UHD, Remux, Dolby Vision & HDR10+."),
        ("[COLOR green][TOP SEED][/COLOR] [B]Xem Mượt Nhất — Nhiều Người Giữ Seed[/B]", "top_seeds", "Danh sách phim có nhiều người đang giữ seed nhất, bấm phát chạy ngay lập tức."),
    ]
    for label, preset, desc in menu_entries:
        add_simple_menu_item(label, build_url(action="browse", preset=preset, page=1), is_folder=True, plot=desc)

    add_simple_menu_item(
        "[COLOR cyan][B][TÌM KIẾM] Tìm Phim Trên VietMediaF Tracker[/B][/COLOR]",
        build_url(action="search"),
        is_folder=True,
        plot="Tìm kiếm theo tên phim (Tiếng Việt / Tiếng Anh) hoặc mã TMDB ID trực tiếp trên VietMediaF.",
    )
    add_simple_menu_item(
        "[COLOR deepskyblue][B][ĐA TRACKER] Tìm Kiếm Trên 45 Tracker UNIT3D (Elementum Burst)[/B][/COLOR]",
        "plugin://plugin.video.elementum/search",
        is_folder=True,
        plot="Mở công cụ tìm kiếm của Elementum và quét đồng thời 45 Private Tracker UNIT3D qua Elementum Burst.",
    )
    add_simple_menu_item(
        "[COLOR lime][B][ELEMENTUM] Mở Giao Diện Elementum (Torrents Đang Tải / Thư Viện)[/B][/COLOR]",
        "plugin://plugin.video.elementum/",
        is_folder=True,
        plot="Mở trực tiếp giao diện quản lý tiến trình tải, bộ nhớ đệm và thư viện của Elementum.",
    )
    add_simple_menu_item(
        "[B][API KEY] Nhập / Đổi API Key VietMediaF Tracker[/B]",
        build_url(action="set_api_key"),
        is_folder=False,
        plot="Cập nhật API Key và tự động đồng bộ sang Elementum Burst.",
    )
    add_simple_menu_item(
        "[B][CÀI ĐẶT] Cài Đặt / Cập Nhật Trình Phát Elementum & Burst (45 UNIT3D)[/B]",
        build_url(action="install_elementum"),
        is_folder=False,
        plot="Tự động tải về, cài đặt và kích hoạt Elementum + Elementum Burst v0.0.103 + Context Menu.",
    )
    add_simple_menu_item(
        "[B][CẤU HÌNH] Thiết Lập Giao Diện & VietMediaF Addon[/B]",
        build_url(action="open_settings"),
        is_folder=False,
        plot="Chỉnh kiểu hiển thị Poster/InfoWall/Wall, ngôn ngữ tiêu đề phim TMDB và cài đặt VietMediaF.",
    )

    xbmcplugin.setContent(HANDLE, "videos")
    xbmcplugin.endOfDirectory(HANDLE, cacheToDisc=False)


def build_filter_params(preset, page=1, query="", tmdb_id="", category_id=""):
    params = {
        "perPage": get_per_page(),
        "page": int(page or 1),
    }
    if tmdb_id:
        params["tmdbId"] = tmdb_id
        params["perPage"] = 100
    if category_id:
        params["categories[0]"] = category_id
    if query:
        if query.isdigit():
            params["tmdbId"] = query
        else:
            params["name"] = query

    if preset == "featured":
        params["featured"] = 1
    elif preset == "movies_new":
        params["categories[0]"] = 1
        params["sortField"] = "created_at"
        params["sortDirection"] = "desc"
    elif preset == "tv_new":
        params["categories[0]"] = 2
        params["sortField"] = "created_at"
        params["sortDirection"] = "desc"
    elif preset == "vie_dub":
        params["name"] = "ViE DUB"
        params["sortField"] = "created_at"
        params["sortDirection"] = "desc"
    elif preset == "vie_sub":
        params["name"] = "ViE"
        params["sortField"] = "created_at"
        params["sortDirection"] = "desc"
    elif preset == "freeleech":
        params["freeleech"] = 1
        params["sortField"] = "created_at"
        params["sortDirection"] = "desc"
    elif preset == "uhd_4k":
        params["resolutions[0]"] = 1
        params["resolutions[1]"] = 2
        params["sortField"] = "created_at"
        params["sortDirection"] = "desc"
    elif preset == "top_seeds":
        params["alive"] = 1
        params["sortField"] = "seeders"
        params["sortDirection"] = "desc"
    else:
        params.setdefault("sortField", "created_at")
        params.setdefault("sortDirection", "desc")

    return params


def extract_torrent_item(raw):
    attrs = raw.get("attributes") or {}
    meta = attrs.get("meta") or {}
    name = attrs.get("name") or "Unknown Release"
    tmdb_id = int(attrs.get("tmdb_id") or 0)
    imdb_id = str(attrs.get("imdb_id") or "")
    if imdb_id and imdb_id != "0" and not imdb_id.startswith("tt"):
        imdb_id = f"tt{imdb_id.zfill(7)}"
    category_id = int(attrs.get("category_id") or 1)
    seeders = int(attrs.get("seeders") or 0)
    leechers = int(attrs.get("leechers") or 0)
    size = int(attrs.get("size") or 0)
    freeleech = str(attrs.get("freeleech") or "0%")
    double_upload = bool(attrs.get("double_upload"))
    featured = bool(attrs.get("featured"))
    resolution = attrs.get("resolution") or ""
    release_type = attrs.get("type") or ""
    download_link = attrs.get("download_link") or ""
    details_link = attrs.get("details_link") or ""
    season_number = int(attrs.get("season_number") or 0)
    episode_number = int(attrs.get("episode_number") or 0)
    if category_id == 2 and season_number == 0 and episode_number == 0:
        season_number, episode_number = parse_season_episode_from_name(name)

    clean_title = meta.get("title") or clean_release_title(name)
    original_title = meta.get("original_title") or clean_title
    year = int(attrs.get("release_year") or 0)
    if not year:
        ym = re.search(r"\b((?:19|20)\d{2})\b", name)
        if ym:
            year = int(ym.group(1))

    raw_poster = meta.get("poster") or ""
    if raw_poster and "/w185/" in raw_poster:
        raw_poster = raw_poster.replace("/w185/", "/w780/")
    elif raw_poster and "/w92/" in raw_poster:
        raw_poster = raw_poster.replace("/w92/", "/w780/")

    poster = raw_poster or ADDON_ICON
    backdrop = meta.get("backdrop") or ADDON_FANART
    overview = meta.get("overview") or ""
    rating = float(meta.get("rating") or 0.0)
    runtime = int(meta.get("runtime") or 0) * 60
    genres = meta.get("genres") or ""

    return {
        "id": raw.get("id"),
        "name": name,
        "title": clean_title,
        "original_title": original_title,
        "year": year,
        "tmdb_id": tmdb_id,
        "imdb_id": imdb_id,
        "category_id": category_id,
        "seeders": seeders,
        "leechers": leechers,
        "size": size,
        "size_str": format_size(size),
        "freeleech": freeleech,
        "double_upload": double_upload,
        "featured": featured,
        "resolution": resolution,
        "type": release_type,
        "download_link": download_link,
        "details_link": details_link,
        "season_number": season_number,
        "episode_number": episode_number,
        "poster": poster,
        "backdrop": backdrop,
        "overview": overview,
        "rating": rating,
        "duration": runtime,
        "genres": genres,
    }


def build_elementum_movie_or_show_item(group_items, tmdb_meta=None):
    """Build an Elementum-identical ListItem dictionary for a grouped Movie or TV Show."""
    primary = group_items[0]
    count = len(group_items)
    is_movie = primary["category_id"] == 1
    media_type = "movie" if is_movie else "tvshow"

    display_title = format_display_title(tmdb_meta, primary["title"])
    orig_title = (tmdb_meta or {}).get("title_orig") or primary["original_title"] or display_title
    year = (tmdb_meta or {}).get("year") or primary["year"] or 0
    release_date = (tmdb_meta or {}).get("release_date") or (f"{year}-01-01" if year else "")
    rating = (tmdb_meta or {}).get("rating") or primary["rating"] or 0.0
    votes = (tmdb_meta or {}).get("votes") or 0
    duration = (tmdb_meta or {}).get("duration") or primary["duration"] or 0
    imdb_id = (tmdb_meta or {}).get("imdb_id") or primary["imdb_id"] or ""
    mpaa = (tmdb_meta or {}).get("mpaa") or ""
    genres = (tmdb_meta or {}).get("genres") or (
        [g.strip() for g in primary["genres"].split(",") if g.strip()] if primary["genres"] else []
    )
    studios = (tmdb_meta or {}).get("studios") or []
    countries = (tmdb_meta or {}).get("countries") or []
    directors = (tmdb_meta or {}).get("directors") or []
    writers = (tmdb_meta or {}).get("writers") or []
    trailer = (tmdb_meta or {}).get("trailer") or ""
    status = (tmdb_meta or {}).get("status") or ""
    castmembers = (tmdb_meta or {}).get("castmembers") or []
    properties = dict((tmdb_meta or {}).get("properties") or {})

    # Summarize Tracker releases cleanly in Tagline and Plot
    resolutions = []
    for gi in group_items:
        if gi["resolution"] and gi["resolution"] not in resolutions:
            resolutions.append(gi["resolution"])
    res_summary = "/".join(resolutions[:3]) or "HD"
    all_names = " ".join(gi["name"] for gi in group_items)
    audio_summary = detect_audio_badges(all_names)
    has_fl = any(gi["freeleech"] != "0%" or gi["featured"] for gi in group_items)
    fl_str = " [COLOR orange][Freeleech][/COLOR]" if has_fl else ""
    total_seeds = sum(gi["seeders"] for gi in group_items)
    seed_color = "lime" if total_seeds > 0 else "red"

    tracker_header = (
        f"[COLOR gold][B]VietMediaF ({count} bản • {res_summary})[/B][/COLOR] "
        f"{audio_summary}{fl_str} — [COLOR {seed_color}][B]Seed: {total_seeds}[/B][/COLOR]"
    )

    version_lines = []
    for gi in group_items[:8]:
        se_tag = ""
        if not is_movie and (gi["season_number"] > 0 or gi["episode_number"] > 0):
            if gi["episode_number"] > 0:
                se_tag = f"[S{gi['season_number']:02d}E{gi['episode_number']:02d}] "
            else:
                se_tag = f"[Season {gi['season_number']:02d}] "
        g_res = " ".join(x for x in [gi["resolution"], gi["type"]] if x).strip()
        g_aud = detect_audio_badges(gi["name"])
        g_fl = " [COLOR orange][FL][/COLOR]" if (gi["freeleech"] != "0%" or gi["featured"]) else ""
        version_lines.append(
            f"• {se_tag}[B]{g_res}[/B] ({gi['size_str']}) {g_aud}{g_fl} — [COLOR lime]Seed: {gi['seeders']}[/COLOR]"
        )

    overview = (tmdb_meta or {}).get("overview") or primary["overview"] or ""
    plot_parts = [tracker_header]
    if overview:
        plot_parts.append(overview)
    plot_parts.append("[B]Các bản phát hành trên Tracker:[/B]\n" + "\n".join(version_lines))
    full_plot = "\n\n".join(plot_parts)

    raw_tagline = (tmdb_meta or {}).get("tagline") or ""
    tagline = f"{tracker_header}" if not raw_tagline else f"{raw_tagline}  |  {tracker_header}"

    # Artwork (Exact Elementum structure)
    if tmdb_meta and tmdb_meta.get("art"):
        art = dict(tmdb_meta["art"])
    else:
        art = {
            "poster": primary["poster"],
            "fanart": primary["backdrop"],
            "thumb": primary["poster"],
            "icon": primary["poster"],
            "landscape": primary["backdrop"],
        }

    # Target URL when user clicks the Poster in Kodi
    if primary["tmdb_id"] > 0:
        target_url = build_url(
            action="select_stream",
            tmdb_id=primary["tmdb_id"],
            category_id=primary["category_id"],
            title=display_title,
            year=year,
            poster=art.get("poster", ""),
        )
    else:
        target_url = build_url(
            action="play_direct",
            download_link=primary["download_link"],
            tmdb_id=0,
            category_id=primary["category_id"],
            title=display_title,
        )

    # Context Menu (Elementum style)
    context_menu = []
    if primary["tmdb_id"] > 0:
        context_menu.append((
            "Chọn bản phát hành trên VietMediaF",
            f"RunPlugin({target_url})",
        ))
        if not is_movie:
            el_seasons_url = f"plugin://plugin.video.elementum/show/{primary['tmdb_id']}/seasons"
            context_menu.append((
                "Duyệt theo Mùa & Tập phim (Elementum Seasons)",
                f"Container.Update({el_seasons_url})",
            ))
        el_burst_url = (
            f"plugin://plugin.video.elementum/movie/{primary['tmdb_id']}/links"
            if is_movie
            else f"plugin://plugin.video.elementum/show/{primary['tmdb_id']}/seasons"
        )
        context_menu.append((
            "Quét 45 Tracker UNIT3D (Elementum Burst)",
            f"Container.Update({el_burst_url})",
        ))
    if trailer:
        context_menu.append((
            "Xem Trailer (YouTube)",
            f"PlayMedia({trailer})",
        ))
    context_menu.append((
        "Đổi kiểu hiển thị (InfoWall / Wall / Poster)",
        f"RunPlugin({build_url(action='cycle_viewmode')})",
    ))

    info = {
        "year": year,
        "date": release_date,
        "premiered": release_date,
        "aired": release_date,
        "title": display_title,
        "originaltitle": orig_title,
        "tvshowtitle": orig_title if not is_movie else "",
        "plot": full_plot,
        "plotoutline": overview or tracker_header,
        "tagline": tagline,
        "duration": duration,
        "code": imdb_id,
        "imdbnumber": imdb_id,
        "votes": str(votes),
        "rating": rating,
        "mpaa": mpaa,
        "mediatype": media_type,
        "genre": genres,
        "studio": studios,
        "country": countries,
        "director": directors,
        "writer": writers,
        "trailer": trailer,
    }
    if status:
        info["status"] = status

    stream_info = {}
    audio_lang = (tmdb_meta or {}).get("audio_lang")
    if audio_lang:
        stream_info["audio"] = {"language": audio_lang}

    uniqueids = {}
    if primary["tmdb_id"] > 0:
        uniqueids["tmdb"] = str(primary["tmdb_id"])
    if imdb_id:
        uniqueids["imdb"] = imdb_id

    return {
        "label": display_title,
        "label2": f"{rating:.1f}" if rating > 0 else "",
        "path": target_url,
        "icon": art.get("thumb") or art.get("poster") or ADDON_ICON,
        "thumbnail": art.get("poster") or ADDON_ICON,
        "info": info,
        "art": art,
        "castmembers": castmembers,
        "stream_info": stream_info,
        "uniqueids": uniqueids,
        "properties": properties,
        "context_menu": context_menu,
        "is_playable": False,
        "is_action": True,
    }


def action_browse(params):
    preset = params.get("preset", "latest_all")
    page = int(params.get("page") or 1)
    query = params.get("query", "")

    api_params = build_filter_params(preset=preset, page=page, query=query)
    payload, err = api_get("/api/torrents/filter", params=api_params)
    if err:
        if "API Key" in err or "401" in err:
            if xbmcgui.Dialog().yesno("Cần cấu hình API Key", f"{err}\n\nBạn có muốn nhập API Key ngay bây giờ không?"):
                action_set_api_key()
        else:
            notify("VietMediaF", err, xbmcgui.NOTIFICATION_ERROR)
        xbmcplugin.endOfDirectory(HANDLE, succeeded=False)
        return

    raw_items = (payload or {}).get("data") or []
    items = [extract_torrent_item(x) for x in raw_items if isinstance(x, dict)]

    if not items:
        notify("VietMediaF", "Không tìm thấy kết quả phù hợp.", xbmcgui.NOTIFICATION_INFO)
        xbmcplugin.endOfDirectory(HANDLE, succeeded=True)
        return

    # Group by (category_id, tmdb_id) to display clean Movie / TV Show cards like Elementum
    groups = OrderedDict()
    tmdb_requests = []
    for item in items:
        if item["tmdb_id"] > 0:
            gkey = (item["category_id"], item["tmdb_id"])
            mtype = "movie" if item["category_id"] == 1 else "tv"
            tmdb_requests.append((mtype, item["tmdb_id"]))
        else:
            gkey = ("raw", item["id"])
        groups.setdefault(gkey, []).append(item)

    # Batch-fetch rich TMDB metadata & artwork in parallel (cached in SQLite)
    tmdb_map = fetch_tmdb_metadata_batch(tmdb_requests)

    content_type = "tvshows" if preset == "tv_new" else "movies"
    apply_elementum_sorting_and_view(content_type=content_type)

    directory_items = []
    for gkey, group_items in groups.items():
        primary = group_items[0]
        mtype = "movie" if primary["category_id"] == 1 else "tv"
        tmdb_meta = tmdb_map.get((mtype, primary["tmdb_id"])) if primary["tmdb_id"] > 0 else None

        el_item_dict = build_elementum_movie_or_show_item(group_items, tmdb_meta=tmdb_meta)
        li = create_elementum_listitem(el_item_dict)
        is_folder = not el_item_dict.get("is_playable") and not el_item_dict.get("is_action")
        directory_items.append((el_item_dict["path"], li, is_folder))

    links = (payload or {}).get("links") or {}
    meta_page = (payload or {}).get("meta") or {}
    current_page = int(meta_page.get("current_page") or page)
    last_page = int(meta_page.get("last_page") or current_page)
    if links.get("next") or current_page < last_page:
        next_page = current_page + 1
        next_li = xbmcgui.ListItem(
            label=f"[COLOR yellow][B]>> Trang tiếp theo (Trang {next_page})[/B][/COLOR]",
            offscreen=True,
        )
        next_li.setArt({"icon": ADDON_ICON, "thumb": ADDON_ICON, "poster": ADDON_ICON, "fanart": ADDON_FANART})
        next_li.setProperty("SpecialSort", "bottom")
        directory_items.append((
            build_url(action="browse", preset=preset, page=next_page, query=query),
            next_li,
            True,
        ))

    xbmcplugin.addDirectoryItems(HANDLE, directory_items, totalItems=len(directory_items))
    xbmcplugin.endOfDirectory(HANDLE, succeeded=True, updateListing=False, cacheToDisc=True)
    trigger_configured_viewmode()


def action_select_stream(params):
    """Elementum-style 2-line detailed Stream Selector Dialog over the Poster view."""
    tmdb_id = int(params.get("tmdb_id") or 0)
    category_id = int(params.get("category_id") or 1)
    title = params.get("title") or "Chọn bản phát hành"
    year = params.get("year") or ""
    poster = params.get("poster") or ADDON_ICON

    api_params = build_filter_params(
        preset="versions",
        page=1,
        tmdb_id=str(tmdb_id),
        category_id=str(category_id),
    )
    payload, err = api_get("/api/torrents/filter", params=api_params)
    if err:
        notify("VietMediaF", err, xbmcgui.NOTIFICATION_ERROR)
        return

    raw_items = (payload or {}).get("data") or []
    items = [extract_torrent_item(x) for x in raw_items if isinstance(x, dict)]
    if not items:
        notify("VietMediaF", "Không tìm thấy bản phát hành nào.", xbmcgui.NOTIFICATION_WARNING)
        return

    if category_id == 2:
        items.sort(key=lambda x: (x["season_number"], x["episode_number"], -x["seeders"], -x["size"]))
    else:
        items.sort(key=lambda x: (-x["seeders"], -x["size"]))

    direct_play_single = ADDON.getSetting("direct_play_single") == "true"
    if len(items) == 1 and direct_play_single and category_id == 1:
        _launch_elementum_playback(
            download_link=items[0]["download_link"],
            tmdb_id=tmdb_id,
            category_id=category_id,
            title=title,
        )
        return

    dialog_list = []
    actions_list = []

    # For TV Shows, offer Elementum's native Seasons -> Episodes browser right at the top
    if category_id == 2 and tmdb_id > 0:
        el_seasons_li = xbmcgui.ListItem(
            label="[COLOR violet][B][MÙA & TẬP] Mở danh sách Mùa & Tập phim (Giao diện Elementum)[/B][/COLOR]",
            label2=f"Duyệt từng Season & Tập của \"{title}\" với ảnh thumbnail và tóm tắt từng tập trên Elementum",
        )
        el_seasons_li.setArt({"icon": poster, "thumb": poster})
        dialog_list.append(el_seasons_li)
        actions_list.append(("container", f"plugin://plugin.video.elementum/show/{tmdb_id}/seasons"))

    for item in items:
        res_type = " ".join(x for x in [item["resolution"], item["type"]] if x).strip() or "Torrent"
        audio_badges = detect_audio_badges(item["name"])
        fl_badge = ""
        if item["featured"]:
            fl_badge = " [COLOR gold][FEATURED][/COLOR]"
        elif item["freeleech"] and item["freeleech"] != "0%":
            fl_badge = f" [COLOR orange][FL {item['freeleech']}][/COLOR]"

        se_badge = ""
        if category_id == 2 and (item["season_number"] > 0 or item["episode_number"] > 0):
            if item["episode_number"] > 0:
                se_badge = f"[COLOR yellow][B]S{item['season_number']:02d}E{item['episode_number']:02d}[/B][/COLOR] • "
            else:
                se_badge = f"[COLOR yellow][B]Trọn bộ Season {item['season_number']:02d}[/B][/COLOR] • "

        seed_color = "lime" if item["seeders"] > 0 else "red"
        line1 = (
            f"{se_badge}[COLOR {seed_color}][B]Seed: {item['seeders']}[/B][/COLOR]  |  "
            f"[COLOR cyan][B]{res_type}[/B][/COLOR]  |  "
            f"[COLOR white][B]{item['size_str']}[/B][/COLOR]  "
            f"{audio_badges}{fl_badge}"
        )
        line2 = item["name"]

        li = xbmcgui.ListItem(label=line1, label2=line2)
        item_poster = poster if poster != ADDON_ICON else item["poster"]
        li.setArt({"icon": item_poster, "thumb": item_poster})
        dialog_list.append(li)
        actions_list.append(("play", item))

    if tmdb_id > 0:
        el_url = (
            f"plugin://plugin.video.elementum/movie/{tmdb_id}/links"
            if category_id == 1
            else f"plugin://plugin.video.elementum/show/{tmdb_id}/seasons"
        )
        burst_li = xbmcgui.ListItem(
            label="[COLOR deepskyblue][B][ĐA TRACKER] Quét thêm bản khác trên 45 Tracker UNIT3D (Elementum Burst)[/B][/COLOR]",
            label2=f"Tìm kiếm \"{title}\" trên toàn bộ 45 Private Tracker UNIT3D đã kích hoạt",
        )
        burst_li.setArt({"icon": poster, "thumb": poster})
        dialog_list.append(burst_li)
        actions_list.append(("container", el_url))

    heading = f"{title} ({year}) — Chọn bản phát hành ({len(items)} bản)" if year else f"{title} — Chọn bản phát hành ({len(items)} bản)"
    selected = xbmcgui.Dialog().select(heading, dialog_list, useDetails=True)
    if selected < 0 or selected >= len(actions_list):
        return

    act_type, payload_obj = actions_list[selected]
    if act_type == "container":
        xbmc.executebuiltin(f"Container.Update({payload_obj})")
    elif act_type == "play":
        _launch_elementum_playback(
            download_link=payload_obj["download_link"],
            tmdb_id=tmdb_id,
            category_id=category_id,
            title=title,
        )


def _launch_elementum_playback(download_link, tmdb_id=0, category_id=1, title="VietMediaF Stream"):
    if not download_link:
        notify("VietMediaF", "Không tìm thấy link tải Torrent.", xbmcgui.NOTIFICATION_ERROR)
        return

    if not has_addon("plugin.video.elementum"):
        if not check_and_install_elementum(force_interactive=True):
            return

    enable_addon("plugin.video.elementum")
    media_type = "movie" if int(category_id or 1) == 1 else "episode"
    el_params = {"uri": download_link, "type": media_type}
    if int(tmdb_id or 0) > 0:
        el_params["tmdb"] = str(tmdb_id)

    elementum_play_url = f"plugin://plugin.video.elementum/play?{urllib.parse.urlencode(el_params)}"
    log(f"Launching Elementum playback: {elementum_play_url}")
    xbmc.executebuiltin(f"PlayMedia({elementum_play_url})")


def action_play_direct(params):
    _launch_elementum_playback(
        download_link=params.get("download_link") or "",
        tmdb_id=int(params.get("tmdb_id") or 0),
        category_id=int(params.get("category_id") or 1),
        title=params.get("title") or "VietMediaF Stream",
    )


def action_cycle_viewmode():
    modes = [
        ("1", "InfoWall (Lưới Poster + Thông tin chi tiết)"),
        ("2", "Wall (Lưới Poster toàn màn hình)"),
        ("3", "Poster (Trượt ngang + Fanart)"),
        ("4", "Shift (Trượt Poster lớn)"),
        ("5", "WideList (Danh sách rộng)"),
        ("0", "Tự động (Nhớ theo Kodi)"),
    ]
    labels = [m[1] for m in modes]
    idx = xbmcgui.Dialog().select("Chọn kiểu hiển thị danh sách phim", labels)
    if idx < 0:
        return
    chosen_key = modes[idx][0]
    ADDON.setSetting("view_mode", chosen_key)
    trigger_configured_viewmode()


def action_search():
    kb = xbmc.Keyboard("", "Tìm kiếm tên phim hoặc mã TMDB ID trên VietMediaF")
    kb.doModal()
    if not kb.isConfirmed():
        xbmcplugin.endOfDirectory(HANDLE, succeeded=False)
        return
    query = (kb.getText() or "").strip()
    if not query:
        xbmcplugin.endOfDirectory(HANDLE, succeeded=False)
        return
    action_browse({"preset": "search", "page": 1, "query": query})


def router():
    query_str = sys.argv[2][1:] if len(sys.argv) > 2 and sys.argv[2].startswith("?") else ""
    params = dict(urllib.parse.parse_qsl(query_str))
    action = params.get("action", "main")

    if action == "main":
        action_main_menu()
    elif action == "browse":
        action_browse(params)
    elif action == "select_stream" or action == "versions":
        action_select_stream(params)
    elif action == "search":
        action_search()
    elif action == "play" or action == "play_direct":
        action_play_direct(params)
    elif action == "cycle_viewmode":
        action_cycle_viewmode()
    elif action == "set_api_key":
        action_set_api_key()
    elif action == "account_info":
        action_account_info()
    elif action == "install_elementum":
        check_and_install_elementum(force_interactive=True)
    elif action == "open_settings":
        ADDON.openSettings()
        sync_api_key_with_burst()
        xbmc.executebuiltin("Container.Refresh")
    else:
        action_main_menu()


if __name__ == "__main__":
    router()
